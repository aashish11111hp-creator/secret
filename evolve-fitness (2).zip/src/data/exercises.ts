import { Exercise } from '../types';

// @ts-ignore
import chestDbPressImg from '../assets/images/chest_db_press_1781880218129.jpg';
// @ts-ignore
import chestBbPressImg from '../assets/images/chest_bb_press_1781880232574.jpg';
// @ts-ignore
import chestPushupImg from '../assets/images/chest_pushup_1781880248002.jpg';
// @ts-ignore
import chestMachinePressImg from '../assets/images/chest_machine_press_1781880264460.jpg';
// @ts-ignore
import chestStretchImg from '../assets/images/chest_stretch_1781880276797.jpg';
// @ts-ignore
import dumbbellShrugsImg from '../assets/images/dumbbell_shrugs_1782028509844.jpg';
// @ts-ignore
import barbellShrugsImg from '../assets/images/barbell_shrugs_1782028524162.jpg';
// @ts-ignore
import dumbbellLateralRaiseImg from '../assets/images/dumbbell_lateral_raise_1782028631250.jpg';
// @ts-ignore
import dbReverseWristCurlImg from '../assets/images/db_reverse_wrist_curl_1782033545806.jpg';
// @ts-ignore
import dbGobletSquatImg from '../assets/images/db_goblet_squat_1782034187982.jpg';
// @ts-ignore
import bodyweightAirSquatsImg from '../assets/images/bodyweight_air_squats_1782034201707.jpg';
// @ts-ignore
import legPressMachineImg from '../assets/images/leg_press_machine_1782034216804.jpg';
// @ts-ignore
import standingQuadStretchImg from '../assets/images/standing_quad_stretch_1782034227906.jpg';
// @ts-ignore
import deadHangImg from '../assets/images/dead_hang_grip_endurance_1782034552727.jpg';
// @ts-ignore
import dbHammerCurlImg from '../assets/images/db_hammer_curl_1782034667996.jpg';
// @ts-ignore
import chinUpUnderhandImg from '../assets/images/chin_up_underhand_1782034683822.jpg';
// @ts-ignore
import cableBicepCurlImg from '../assets/images/cable_bicep_curl_1782034698428.jpg';
// @ts-ignore
import bicepWallStretchImg from '../assets/images/bicep_wall_stretch_1782034714963.jpg';

export const exercises: Exercise[] = [
  // --- CHEST EXERCISES ---
  {
    id: 'chest-db-press',
    name: 'Dumbbell Bench Press',
    muscle: 'chest',
    equipment: 'dumbbell',
    difficulty: 'Beginner',
    targets: ['Pectoralis Major', 'Triceps Brachii', 'Anterior Deltoids'],
    instructions: [
      'Lie flat on a horizontal bench holding two dumbbells at chest level with an overhand grip (palms facing forward).',
      'Keep your feet flat on the floor and your upper back firmly supported by the bench.',
      'Press the dumbbells upward above your chest until your arms are fully extended but not locked.',
      'Lower the weights slowly and under control back to the starting chest level, maintaining a 45-degree elbow angle to the torso.'
    ],
    proTip: 'Squeeze your shoulder blades together at the bottom of the movement to create a stable chest pressing platform and protect your rotator cuffs.',
    imageUrl: chestDbPressImg,
    youtubeUrl: 'https://www.youtube.com/watch?v=5cy8pPT0bs0'
  },
  {
    id: 'chest-bb-press',
    name: 'Barbell Bench Press',
    muscle: 'chest',
    equipment: 'barbell',
    difficulty: 'Intermediate',
    targets: ['Pectoralis Major', 'Triceps', 'Serratus Anterior', 'Anterior Deltoid'],
    instructions: [
      'Lie flat on the bench, lining up your eyes directly beneath the loaded barbell.',
      'Grip the bar with hands slightly wider than shoulder-width, wrapping your thumbs securely around the barbell.',
      'Unrack the bar and position it directly over your middle chest.',
      'Inhale and lower the bar under control until it gently touches your sternum.',
      'Exhale and press the bar straight back up to the starting position.'
    ],
    proTip: 'Keep your feet screwed into the floor and drive through your heels to generate leg drive, which stabilizes your spine and increases pressing power.',
    imageUrl: chestBbPressImg,
    youtubeUrl: 'https://www.youtube.com/watch?v=4Y2ZdHCOXok'
  },
  {
    id: 'chest-pushup',
    name: 'Bodyweight Push-Up',
    muscle: 'chest',
    equipment: 'bodyweight',
    difficulty: 'Beginner',
    targets: ['Pectoralis Major', 'Anterior Deltoids', 'Triceps', 'Core stabilizers'],
    instructions: [
      'Begin in a high plank position with your hands slightly wider than shoulder-width apart and fingers pointed forward.',
      'Maintain a rigid straight line from your ears down to your toes, bracing your abs and glutes.',
      'Lower your chest toward the floor by bending your elbows backwards at a 45-degree angle.',
      'Push hard against the ground to return to the starting plank position.'
    ],
    proTip: 'Never let your lower back sag. Imagine pushing the floor away from you rather than raising your body.',
    imageUrl: chestPushupImg,
    youtubeUrl: 'https://www.youtube.com/watch?v=IODxDxX7oi4'
  },
  {
    id: 'chest-machine-press',
    name: 'Seated Chest Press Machine',
    muscle: 'chest',
    equipment: 'machines',
    difficulty: 'Beginner',
    targets: ['Pectoralis Major', 'Anterior Deltoids', 'Triceps'],
    instructions: [
      'Adjust the seat height so that the handles sit in line with your mid-to-lower chest level.',
      'Sit back firmly against the padding and place both feet flat on the floor.',
      'Grip the handles and push them forward until your arms are nearly straight.',
      'Slowly guide the handles back toward your chest until you feel a comfortable stretch in your pecs, then repeat.'
    ],
    proTip: 'Do not let the weight stack touch at the bottom of the repetition. Maintain continuous tension on the pecs.',
    imageUrl: chestMachinePressImg,
    youtubeUrl: 'https://youtu.be/xUm0BiZCWlQ?si=NpH-Ud06rsN_DXv1'
  },
  {
    id: 'chest-stretch',
    name: 'Doorway Pec Stretch',
    muscle: 'chest',
    equipment: 'stretches',
    difficulty: 'Beginner',
    targets: ['Pectoralis Major', 'Pectoralis Minor', 'Anterior Deltoid'],
    instructions: [
      'Stand inside a doorway with your forearms braced flat against the door frame, elbows bent at 90 degrees.',
      'Step one foot forward slowly until you feel a gentle, deep stretch in your chest muscles.',
      'Hold the position for 20 to 30 seconds while breathing deeply.',
      'Step back, release the stretch, and switch to lead with the other foot.'
    ],
    proTip: 'Vary the height of your elbows on the door frame to target the upper, middle, and lower divisions of the chest.',
    imageUrl: chestStretchImg,
    youtubeUrl: 'https://youtu.be/Dmm8_S23I74?si=X97czIWK8UclHfH_'
  },

  // --- QUADS ---
  {
    id: 'quads-bb-squat',
    name: 'Barbell Back Squat',
    muscle: 'quads',
    equipment: 'barbell',
    difficulty: 'Intermediate',
    targets: ['Quadriceps Femoris', 'Gluteus Maximus', 'Hamstrings', 'Erector Spinae'],
    instructions: [
      'Rest the barbell across your upper traps (not your neck). Grip the bar firmly, pull it down into your shoulders, and lift it from the rack.',
      'Take two steps back, putting your feet shoulder-width apart with toes flared slightly outward (15 to 30 degrees).',
      'Inhale, brace your core, and push your hips back while bending your knees to descend.',
      'Lower until your thighs are at least parallel to the floor, keeping your back flat and chest upright.',
      'Drive through your mid-foot to stand back up, exhaling at the top.'
    ],
    proTip: 'Keep your knees tracking in line with your toes. Do not let your knees buckle inward during the ascent.',
    imageUrl: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://youtu.be/SW_C1A-rejs?si=Eb5MMf84SPn7VGpI'
  },
  {
    id: 'quads-db-squat',
    name: 'Dumbbell Goblet Squat',
    muscle: 'quads',
    equipment: 'dumbbell',
    difficulty: 'Beginner',
    targets: ['Quadriceps', 'Glutus', 'Core Stabilizers'],
    instructions: [
      'Hold a single dumbbell vertically close to your chest, grabbing the top bell with both palms facing upward.',
      'Position your feet slightly wider than shoulder-width, bracing your core and keeping your chest high.',
      'Lower your body by sitting back and pushing knees out, keeping the weight close to your body.',
      'Go down until your elbows touch your inner knees, then stand up explosively.'
    ],
    proTip: 'This is a fantastic exercise to master squad depth and upright alignment before moving to heavy barbells.',
    imageUrl: dbGobletSquatImg,
    youtubeUrl: 'https://youtu.be/2LnkzQ7paAc?si=9tBHXUnaLOW5C4E4'
  },
  {
    id: 'quads-bodyweight',
    name: 'Bodyweight Air Squats',
    muscle: 'quads',
    equipment: 'bodyweight',
    difficulty: 'Beginner',
    targets: ['Quadriceps', 'Gluteus Maximus', 'Adductors'],
    instructions: [
      'Stand with feet shoulder-width apart, arms extended in front of your chest for balance.',
      'Bend knees and push hips back as if you are sitting on an invisible chair.',
      'Ensure your weight is distributed evenly across your feet, with heels grounded.',
      'Maintain an upright torso and push through the heels to stand.'
    ],
    proTip: 'Perform this with a slow tempo (3 seconds down, 1 second hold at bottom) to maximize quad activation without equipment.',
    imageUrl: bodyweightAirSquatsImg,
    youtubeUrl: 'https://youtu.be/zhGVm7IBPuY?si=5hKsqoK8OOqjt_wO'
  },
  {
    id: 'quads-machine-press',
    name: 'Leg Press Machine',
    muscle: 'quads',
    equipment: 'machines',
    difficulty: 'Beginner',
    targets: ['Quadriceps', 'Gluteus', 'Hamstrings'],
    instructions: [
      'Sit in the leg press machine, place your feet shoulder-width apart on the sled platform.',
      'Release the safety locks and slowly lower the sled towards your chest by bending your knees to 90 degrees.',
      'Press the sled away by extending your legs, making sure not to lock out your knees completely at the top.'
    ],
    proTip: 'Never let your lower back lift off the back pad. Keeping your tailbone glued down protects your lumbar spine!',
    imageUrl: legPressMachineImg,
    youtubeUrl: 'https://youtube.com/shorts/EotSw18oR9w?si=OrjBf6rxmLyR5-md'
  },
  {
    id: 'quads-stretch',
    name: 'Standing Quad Stretch',
    muscle: 'quads',
    equipment: 'stretches',
    difficulty: 'Beginner',
    targets: ['Rectus Femoris', 'Iliopsoas'],
    instructions: [
      'Stand on one leg, holding onto a wall or sturdy object for balance.',
      'Bend your other knee, reach behind, and grab your ankle with the same-side hand.',
      'Gently pull your heel toward your butt, keeping your knees close together and hips pushed forward.'
    ],
    proTip: 'Squeeze your glutes on the side being stretched to deepen the release of your hip flexor.',
    imageUrl: standingQuadStretchImg,
    youtubeUrl: 'https://youtube.com/shorts/Ztwz8rrDShk?si=983n3d9ugbGxdx8G'
  },

  // --- BICEPS ---
  {
    id: 'biceps-bb-curl',
    name: 'Barbell Bicep Curl',
    muscle: 'biceps',
    equipment: 'barbell',
    difficulty: 'Beginner',
    targets: ['Biceps Brachii', 'Brachialis', 'Brachioradialis'],
    instructions: [
      'Stand erect holding a barbell with an underhand grip (palms up), hands shoulder-width apart.',
      'Position elbows close to your torso. Keep your upper arms stationary.',
      'Squeeze your biceps and curl the weight upwards while exhaling, moving only your forearms.',
      'Squeeze at the top, then slowly lower the bar back to the starting point.'
    ],
    proTip: 'Keep your elbows tucked into your ribs and stationary. Avoid swaying your torso to lift the barbell.',
    imageUrl: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://youtu.be/kwG2ipFRgfo?si=PP_1dptzVDBraebq'
  },
  {
    id: 'biceps-db-curl',
    name: 'Dumbbell Hammer Curl',
    muscle: 'biceps',
    equipment: 'dumbbell',
    difficulty: 'Beginner',
    targets: ['Brachialis', 'Brachioradialis', 'Biceps Brachii (Outer Head)'],
    instructions: [
      'Stand with a dumbbell in each hand, arms hanging down by your sides with a neutral grip (palms facing inward).',
      'Keep your elbows pinned. Curl the weights upward while maintaining the neutral hand position.',
      'Squeeze the top range, then lower the dumbbells slowly back down.'
    ],
    proTip: 'Hammer curls build the brachialis muscle, sand-wiched between your biceps and triceps, making your arm look much thicker.',
    imageUrl: dbHammerCurlImg,
    youtubeUrl: 'https://youtu.be/zC3nLlEvin4?si=pOYOdGxGJj7qODC2'
  },
  {
    id: 'biceps-bodyweight',
    name: 'Chin-Up (Underhand Pull-up)',
    muscle: 'biceps',
    equipment: 'bodyweight',
    difficulty: 'Advanced',
    targets: ['Biceps Brachii', 'Latissimus Dorsi', 'Teres Major'],
    instructions: [
      'Grasp a pullbar with a shoulder-width underhand grip (palms facing your face).',
      'Hang with arms fully extended. Pull your shoulder blades down and back.',
      'Pull your weight up by contracting your biceps and lats, until your chin clears the bar.',
      'Slowly lower yourself down to a dead hang.'
    ],
    proTip: 'Tense your core and squeeze your legs together to remove momentum and maximize bicep tension.',
    imageUrl: chinUpUnderhandImg,
    youtubeUrl: 'https://www.youtube.com/watch?v=XlpvF_DIsX8'
  },
  {
    id: 'biceps-machine',
    name: 'Cable Biceps Curl',
    muscle: 'biceps',
    equipment: 'machines',
    difficulty: 'Beginner',
    targets: ['Biceps Brachii', 'Brachioradialis'],
    instructions: [
      'Attach a straight or EZ-bar to the low pulley of a cable stack.',
      'Grasp the bar with an underhand grip, step back slightly, and tuck your elbows in.',
      'Curl the cable handle upward toward your shoulders, resisting the cable force.',
      'Slowly release back down, feeling the constant tension of the cable.'
    ],
    proTip: 'Because cables provide horizontal and vertical tension, they maintain peak muscle loading across the entire range.',
    imageUrl: cableBicepCurlImg,
    youtubeUrl: 'https://youtube.com/shorts/4XQLqBelbPw?si=EKxAfPVy574aJlRv'
  },
  {
    id: 'biceps-stretch',
    name: 'Standing Bicep Wall Stretch',
    muscle: 'biceps',
    equipment: 'stretches',
    difficulty: 'Beginner',
    targets: ['Biceps Brachii', 'Brachialis', 'Anterior Deltoids'],
    instructions: [
      'Place the palm of your hand flat against a wall or post, at shoulder height.',
      'Point your fingers backwards. Keeping your arm extended gently, slowly turn your torso away from the wall.',
      'Hold the stretch as you feel the pull in your inner elbow, bicep, and chest.'
    ],
    proTip: 'Avoid shrugging your shoulder up. Keep your shoulder blades dropped down throughout the stretch.',
    imageUrl: bicepWallStretchImg,
    youtubeUrl: 'https://youtube.com/shorts/j0rdJpN4B8Y?si=ERucX0Mefelu9Rui'
  },

  // --- LATS ---
  {
    id: 'lats-bb-row',
    name: 'Barbell Bent-Over Row',
    muscle: 'lats',
    equipment: 'barbell',
    difficulty: 'Intermediate',
    targets: ['Latissimus Dorsi', 'Rhomboids', 'Trapezius', 'Rear Deltoids'],
    instructions: [
      'Stand with feet hip-width apart. Hold a barbell with an overhand grip.',
      'Hinge forward at your hips, keeping your back straight and knees slightly bent, until your torso is at a 45-degree angle.',
      'Let the bar hang straight down. Contract your core and pull the bar to your lower rib/belly button.',
      'Focus on pulling your elbows towards the ceiling and squeezing your shoulder blades, then slowly lower the bar.'
    ],
    proTip: 'Pull with your elbows, not your hands. This shift in mental focus dramatically improves lat activation.',
    imageUrl: 'https://images.unsplash.com/photo-1605296867424-35fc25c9507d?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://www.youtube.com/watch?v=FWJR5Ve8AWI'
  },
  {
    id: 'lats-db-row',
    name: 'Single-Arm Dumbbell Row',
    muscle: 'lats',
    equipment: 'dumbbell',
    difficulty: 'Beginner',
    targets: ['Latissimus Dorsi', 'Rhomboids', 'Teres Major'],
    instructions: [
      'Place your right knee and right hand firmly on a flat bench. Your back should be flat and parallel to the bench.',
      'Hold a dumbbell in your left hand, arm fully extended toward the floor.',
      'Pull the dumbbell up by driving your left elbow backwards to your hip, keeping it close to your torso.',
      'Slowly return the weight down.'
    ],
    proTip: 'Perform a full sweep! Stretch the arm out and slightly forward on the descent, then pull it back and up toward your pant pocket.',
    imageUrl: 'https://images.unsplash.com/photo-1434608519344-49d77a699e1d?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://www.youtube.com/watch?v=dFzUjAs_KGU'
  },
  {
    id: 'lats-bodyweight',
    name: 'Strict dead-hang Pull-Up',
    muscle: 'lats',
    equipment: 'bodyweight',
    difficulty: 'Advanced',
    targets: ['Latissimus Dorsi', 'Rhomboids', 'Middle/Lower Trapezius', 'Teres Major'],
    instructions: [
      'Hang from a pullbar with your hands wider than shoulder-width using an overhand grip (palms outward).',
      'Squeeze your core and pull your shoulder blades down.',
      'Pull yourself upward by driving your elbows toward the ground. Attempt to touch your collarbone to the bar.',
      'Under absolute control, lower your body to a dead hang.'
    ],
    proTip: 'If your chest is caving in, pull-ups will target your arms. Puff your chest out to meet the bar to load the lats.',
    imageUrl: 'https://images.unsplash.com/photo-1598971639058-fab3c3109a00?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://www.youtube.com/watch?v=iW9m98fL62I'
  },
  {
    id: 'lats-machine',
    name: 'Wide-Grip Lat Pulldown',
    muscle: 'lats',
    equipment: 'machines',
    difficulty: 'Beginner',
    targets: ['Latissimus Dorsi', 'Teres Major', 'Rhomboids'],
    instructions: [
      'Sit comfortably in a lat pulldown station and adjust the thigh pads.',
      'Grasp the wide bar with a pronated (overhand) grip, hands wider than shoulder-width.',
      'Lean back slightly (10-15 degrees) and pull the bar down to your upper chest.',
      'Keep your elbows pointing directly straight down, then slowly return the bar up.'
    ],
    proTip: 'Do not use your lower back to yank the weight down. Maintain a fixed torso angle.',
    imageUrl: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://www.youtube.com/watch?v=lueEJGjTuPQ'
  },
  {
    id: 'lats-stretch',
    name: 'Kneeling Lat Stretch on Bench',
    muscle: 'lats',
    equipment: 'stretches',
    difficulty: 'Beginner',
    targets: ['Latissimus Dorsi', 'Teres Major'],
    instructions: [
      'Kneel in front of a flat bench. Place both elbows on the edge of the bench, holding hands together.',
      'Slowly sit back toward your heels and drop your head and upper chest between your arms.',
      'Push your armpits down toward the floor until you feel a wide, deep stretch in your back.'
    ],
    proTip: 'Bending your arms and bringing your hands to touch the back of your neck will intensify the stretch along your triceps and lats.',
    imageUrl: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://www.youtube.com/watch?v=VwzX_rN-FvU'
  },

  // --- TRICEPS ---
  {
    id: 'triceps-bb-skull',
    name: 'EZ-Bar Skull Crusher',
    muscle: 'triceps',
    equipment: 'barbell',
    difficulty: 'Intermediate',
    targets: ['Triceps Brachii (Long and Lateral Heads)'],
    instructions: [
      'Lie flat on a bench, holding an EZ bar or barbell directly over your shoulders with an overhand grip.',
      'Fix your upper arms vertically. Bend only your elbows to lower the bar towards your forehead or crown of your head.',
      'Just before touching, use your triceps to press the bar back up to the vertical position.'
    ],
    proTip: 'Angling your upper arms slightly backward (towards your head, about 10 degrees) keeps constant tension on the triceps at the very top of the rep.',
    imageUrl: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://www.youtube.com/watch?v=d_KZxkY_0cM'
  },
  {
    id: 'triceps-db-ext',
    name: 'Overhead Dumbbell Triceps Extension',
    muscle: 'triceps',
    equipment: 'dumbbell',
    difficulty: 'Beginner',
    targets: ['Triceps Brachii (Long Head)'],
    instructions: [
      'Sit on a short bench, holding a dumbbell with both hands underneath the top plate forming a diamond shape with index fingers and thumbs.',
      'Press the weight overhead, keeping your core stable and elbows close to your head.',
      'Lower the dumbbell behind your head by bending your elbows past 90 degrees.',
      'Contract your triceps to press the weight back overhead.'
    ],
    proTip: 'Keep your elbows pointed forward, not flared out, to place maximum stretch on the long head of the tricep.',
    imageUrl: 'https://images.unsplash.com/photo-1593079831268-3381b0db4a77?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://www.youtube.com/watch?v=X-iV-sL0U_o'
  },
  {
    id: 'triceps-bodyweight',
    name: 'Bench Dips',
    muscle: 'triceps',
    equipment: 'bodyweight',
    difficulty: 'Beginner',
    targets: ['Triceps Brachii', 'Anterior Deltoids', 'Pectoralis Major'],
    instructions: [
      'Sit on the edge of a bench. Place your hands close to your hips on the edge, fingers pointing forward.',
      'Slide your butt off the bench, extending your legs out in front (bend knees for an easier variation).',
      'Bend your elbows to lower your hips towards the floor until upper arms are parallel to the ground.',
      'Press back up using only arm extension.'
    ],
    proTip: 'Keep your back very close to the bench during descent to avoid putting excessive stress on your shoulder joints.',
    imageUrl: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://www.youtube.com/watch?v=0326m9YcJsc'
  },
  {
    id: 'triceps-machine',
    name: 'Cable Rope Tricep Pushdown',
    muscle: 'triceps',
    equipment: 'machines',
    difficulty: 'Beginner',
    targets: ['Triceps Brachii (Lateral & Medial Heads)'],
    instructions: [
      'Attach a rope handle to a high cable pulley. Stand facing the pulley, feet shoulder-width apart.',
      'Hold the rope handles and bend elbows to 90 degrees, pinning them close to your ribs.',
      'Push the rope straight down, pulling the rope ends apart at the bottom to maximize final contraction.',
      'Slowly return up to chest level.'
    ],
    proTip: 'Focus on separating the ends of the rope at the bottom of the movement. This flares the lateral tricep head for a horseshoe look.',
    imageUrl: 'https://images.unsplash.com/photo-1546483875-06048ec909a7?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://www.youtube.com/watch?v=vB5OHsJ3EME'
  },
  {
    id: 'triceps-stretch',
    name: 'Overhead Tricep Stretch',
    muscle: 'triceps',
    equipment: 'stretches',
    difficulty: 'Beginner',
    targets: ['Triceps Brachii'],
    instructions: [
      'Raise one arm straight up and bend your elbow, reaching your hand down your spine between your shoulder blades.',
      'Use your opposite hand to gently press down on your raised elbow, deepening the stretch.',
      'Hold for 20 seconds, then release and swap arms.'
    ],
    proTip: 'Keep your head high and looking forward. Don\'t tuck your chin to your chest.',
    imageUrl: 'https://images.unsplash.com/photo-1599447421416-3414500d18a5?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://www.youtube.com/watch?v=Kz69k1fQ-Y8'
  },

  // --- ABS ---
  {
    id: 'abs-ab-wheel-rollout',
    name: 'Ab Wheel Rollout',
    muscle: 'abs',
    equipment: 'bodyweight',
    difficulty: 'Advanced',
    targets: ['Rectus Abdominis (Full Core)'],
    instructions: [
      'Kneel on the floor with the wheel beneath your shoulders.',
      'Roll the wheel straight forward, keeping your core braced firmly.',
      'Pull yourself back using your abs.'
    ],
    proTip: 'Tuck your tailbone under (posterior pelvic tilt) and brace your abs before rolling out to maximize recruitment and protect your lower spine.',
    imageUrl: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://youtu.be/A3uK5TPzHq8?si=iv6Po6ww13JOrwNd'
  },
  {
    id: 'abs-hanging-leg-raise',
    name: 'Hanging Leg Raise',
    muscle: 'abs',
    equipment: 'bodyweight',
    difficulty: 'Intermediate',
    targets: ['Lower Abdominals'],
    instructions: [
      'Hang from a pull-up bar with straight arms and a tight grip.',
      'Raise your legs slowly without swinging your body.',
      'Lower them back down with control.'
    ],
    proTip: 'Initiate the movement by contracting your lower abdominals rather than pulling with your hip flexors.',
    imageUrl: 'https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://youtube.com/shorts/UqmbxvOgnX4?si=8-rz96tMVK15GlUO'
  },
  {
    id: 'abs-cable-crunch',
    name: 'Cable Crunch',
    muscle: 'abs',
    equipment: 'machines',
    difficulty: 'Beginner',
    targets: ['Upper Abdominals'],
    instructions: [
      'Kneel below a high pulley cable with the rope attachment.',
      'Flex at the hips and crunch down, bringing elbows toward knees.',
      'Slowly return to starting position.'
    ],
    proTip: 'Lock your hips in place and isolate the trunk movement to flex your abdominal wall rather than sitting on your heels.',
    imageUrl: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://youtube.com/shorts/K2m0jj6RfYg?si=Sg_O-NL0eJ405d-H'
  },
  {
    id: 'abs-db-twist',
    name: 'Dumbbell Russian Twist',
    muscle: 'abs',
    equipment: 'dumbbell',
    difficulty: 'Intermediate',
    targets: ['Internal/External Obliques', 'Rectus Abdominis', 'Transverse Abdominis'],
    instructions: [
      'Sit on the floor, knees bent and feet hovered slightly off the ground. Lean your torso back at a 45-degree angle.',
      'Hold a single dumbbell close to your chest with both hands.',
      'Twist your torso completely to the right, tapping the weight close to the ground.',
      'Rotate your chest all the way to the left, repeating in a controlled cadence.'
    ],
    proTip: 'Follow the movement of your hands with your gaze to ensure high-quality rotative spinal torque from the trunk.',
    imageUrl: 'https://images.unsplash.com/photo-1507398941214-572c25f4b1dc?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://youtu.be/pDTHSnoGoEc?si=IRTEZwunOoHM6aeI'
  },
  {
    id: 'abs-stretch',
    name: 'Cobra Abs Stretch',
    muscle: 'abs',
    equipment: 'stretches',
    difficulty: 'Beginner',
    targets: ['Rectus Abdominis', 'Transverse Abdominis'],
    instructions: [
      'Lie face down on the floor with your legs straight out behind you.',
      'Place your palms flat on the ground directly beneath your shoulders, elbows tucked to your ribs.',
      'Push up, straightening your arms and lifting your chest high off the floor while keeping your pelvis grounded.'
    ],
    proTip: 'Do not push past pain, and do not shrug. Relax your shoulders down to feel the anterior abdominal sheath opening up.',
    imageUrl: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://youtu.be/lxl_mH4BPN4?si=NBEWERlMhGfCIpm5'
  },

  // --- SHOULDERS ---
  {
    id: 'shoulders-bb-press',
    name: 'Barbell Military Overhead Press',
    muscle: 'shoulders',
    equipment: 'barbell',
    difficulty: 'Advanced',
    targets: ['Anterior Deltoids', 'Lateral Deltoids', 'Triceps', 'Upper Traps', 'Core'],
    instructions: [
      'Set a barbell in a rack at upper shoulder height. Grip the bar just outside shoulder-width under hand.',
      'Unrack the bar and rest it across your anterior shoulders. Lock your knees and squeeze your glutes.',
      'Press the bar straight overhead, moving your head slightly backward to clear the bar line.',
      'Once the bar clears your forehead, push your head back to neutral, locking the bar out directly overhead.'
    ],
    proTip: 'Squeezing your glutes hard is the secret tip to protect your lower back and generate a rock-solid vertical structural column.',
    imageUrl: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://youtu.be/KP1sYz2VICk?si=XhktGb1LKYseG9wD'
  },
  {
    id: 'shoulders-db-raise',
    name: 'Dumbbell Lateral Raise',
    muscle: 'shoulders',
    equipment: 'dumbbell',
    difficulty: 'Beginner',
    targets: ['Lateral Deltoids (Side Delts)'],
    instructions: [
      'Stand with feet hip-width, holding dumbbells at your sides, palms facing inwards. Lean forward slightly.',
      'Keeping a tiny bend in your elbows, raise the dumbbells out and up in a wide arc (scapular plane).',
      'Raise until your elbows are at shoulder height (paralell to the ground), palms pointing down.',
      'Slowly trace the arc back down.'
    ],
    proTip: 'Pour the water! Lead the motion with your elbows. To isolate the lateral delt, make sure your wrists do not rise above your elbows.',
    imageUrl: dumbbellLateralRaiseImg,
    youtubeUrl: 'https://youtube.com/shorts/Kl3LEzQ5Zqs?si=_JQazAiAAleS2fnT'
  },
  {
    id: 'shoulders-pushup',
    name: 'Bodyweight Pike Push-Up',
    muscle: 'shoulders',
    equipment: 'bodyweight',
    difficulty: 'Intermediate',
    targets: ['Anterior Deltoids', 'Triceps', 'Upper Pectorals', 'Serratus'],
    instructions: [
      'Assume a pushup position, then walk your feet forward and hike your hips into the air (resembling an upside-down V shape).',
      'Keeping your head in line with your spine, bend your elbows to lower your head forward towards the ground.',
      'Push your shoulders back up, extending arms and returning to the pike pyramid.'
    ],
    proTip: 'Angle your head forward to form a tripod shape with your hands at the bottom, which is a safer pressing angle for shoulders.',
    imageUrl: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://youtube.com/shorts/UalsVVpBacw?si=0Ya1ZrZiLQ9U7LcZ'
  },
  {
    id: 'shoulders-machine-press',
    name: 'Seated Shoulder Press Machine',
    muscle: 'shoulders',
    equipment: 'machines',
    difficulty: 'Beginner',
    targets: ['Anterior Deltoids', 'Lateral Deltoids', 'Triceps'],
    instructions: [
      'Adjust the seat height so that the grips align with your chin or jaw level.',
      'Sit firmly back against the padding, grasp the horizontal handles, and press straight overhead.',
      'Lower the weight stack under absolute control until your hands are back in line with your ears before pushing up.'
    ],
    proTip: 'Avoid using a heavy arch in your lower back. Sit fully flush against the backplate to keep shoulder press linear.',
    imageUrl: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://youtube.com/shorts/nj_HpigClV0?si=3x7bvYuwFsbtnNmT'
  },
  {
    id: 'shoulders-stretch',
    name: 'Cross-Body Shoulder Stretch',
    muscle: 'shoulders',
    equipment: 'stretches',
    difficulty: 'Beginner',
    targets: ['Posterior Deltoid (Rear Shoulder)', 'Infraspinatus'],
    instructions: [
      'Bring your right arm straight across your body at chest level.',
      'Hook your left forearm under your right arm, pulling your right elbow tight towards your left shoulder.',
      'Keep your shoulders down, relax the neck, and hold for 20 seconds.'
    ],
    proTip: 'Avoid rotating your torso. Keep your chest pointing straight ahead to lock the stretch strictly inside the shoulder joint.',
    imageUrl: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://youtu.be/swvXpKN832E?si=hbT7C_MnsEE_euI5'
  },

  // --- FOREARMS ---
  {
    id: 'forearms-bb-curl',
    name: 'Barbell Wrist Curl',
    muscle: 'forearms',
    equipment: 'barbell',
    difficulty: 'Beginner',
    targets: ['Forearm Flexors'],
    instructions: [
      'Sit on a bench, resting your forearms flat along your thighs with your wrists hanging off the edges.',
      'Hold a barbell with an underhand grip (palms up).',
      'Allow the bar to roll down/stretch your fingertips open, then curl your wrists upward to raise the bar.'
    ],
    proTip: 'Do not squeeze the bar so tightly that your wrists cannot flex. A loose grip activates the deep forearm tendons.',
    imageUrl: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://youtube.com/shorts/d5YiFNoiCa0?si=c_9pzKT8KGKE0S7T'
  },
  {
    id: 'forearms-db-reverse',
    name: 'Dumbbell Reverse Wrist Curl',
    muscle: 'forearms',
    equipment: 'dumbbell',
    difficulty: 'Beginner',
    targets: ['Forearm Extensors'],
    instructions: [
      'Sit on a bench, rest your forearms flat along your thighs with wrists hanging off knees, using an overhand grip (palms down).',
      'Hold a dumbbell in each hand.',
      'Raise the dumbbells up by extending your wrists, then slowly lower them.'
    ],
    proTip: 'Extensors are vital for preventing tennis elbow (lateral epicondylitis). Support with high reps (15-20).',
    imageUrl: dbReverseWristCurlImg,
    youtubeUrl: 'https://youtu.be/osYPwlBiCRM?si=rwjfF1rifrHTvnEd'
  },
  {
    id: 'forearms-hang',
    name: 'Dead Hang (Grip Endurance)',
    muscle: 'forearms',
    equipment: 'bodyweight',
    difficulty: 'Beginner',
    targets: ['Forearm Flexors', 'Grip strength muscles', 'Rotator cuff stabilizers'],
    instructions: [
      'Grasp a pull up bar firmly shoulder-width apart with an overhand grip.',
      'Step off your platform and dangle with dead vertical arms.',
      'Brace your core slightly and hold for as long as possible (target: 30-90 seconds).'
    ],
    proTip: 'Try wrapping a towel around the bar (thick bar training) to double the required grip pressure and build thicker forearms!',
    imageUrl: deadHangImg,
    youtubeUrl: 'https://youtu.be/MJRgqJVKMyA?si=H9qTX3OSq7EcDkA_'
  },

  // --- TRAPS ---
  {
    id: 'traps-bb-shrug',
    name: 'Barbell Shrugs',
    muscle: 'traps',
    equipment: 'barbell',
    difficulty: 'Beginner',
    targets: ['Upper Trapezius', 'Levator Scapulae'],
    instructions: [
      'Stand holding a barbell in front of your thighs with a shoulder-width overhand grip.',
      'Keep your arms perfectly straight.',
      'Elevate your shoulders towards your ears as high as possible, squeezing the traps at the peak.',
      'Slowly lower back down to the starting point.'
    ],
    proTip: 'Do NOT roll your shoulders in circles (rolling backward). This places unnecessary friction on the rotator cuffs. Keep it straight up and straight down.',
    imageUrl: barbellShrugsImg,
    youtubeUrl: 'https://youtube.com/shorts/nd8eNnkFOKU?si=Q7PVRU_mw3vmGja8'
  },
  {
    id: 'traps-db-shrug',
    name: 'Dumbbell Shrugs',
    muscle: 'traps',
    equipment: 'dumbbell',
    difficulty: 'Beginner',
    targets: ['Upper Trapezius'],
    instructions: [
      'Hold dumbbells at your sides, keeping a neutral posture, arms straight.',
      'Shrug your shoulders upwards towards your ears, holding for 1-2 seconds with peak contraction.',
      'Lower the weights under solid control.'
    ],
    proTip: 'Perform this with a slight forward hinge of the chest (about 10 degrees) to align the pull with the actual fibers of the upper traps.',
    imageUrl: dumbbellShrugsImg,
    youtubeUrl: 'https://youtube.com/shorts/1OY7v02l2vA?si=K5sJnK6v3x6WY4zI'
  },

  // --- HAMSTRINGS ---
  {
    id: 'hamstrings-bb-deadlift',
    name: 'Barbell Romanian Deadlift (RDL)',
    muscle: 'hamstrings',
    equipment: 'barbell',
    difficulty: 'Intermediate',
    targets: ['Hamstrings', 'Gluteus Maximus', 'Erector Spinae'],
    instructions: [
      'Stand with feet hip-width apart, holding a barbell with a shoulder-width overhand grip in front of your hips.',
      'With knees soft (bent slightly but locked in place), push your hips far backwards to descend.',
      'Keep the bar sliding down close against your shins, maintaining a flat back.',
      'Lower until you feel a deep stretch in your hamstrings, then push hips forward to stand.'
    ],
    proTip: 'Think of this as a horizontal movement, not vertical. Push your hips back as if trying to close a car door with your butt!',
    imageUrl: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://www.youtube.com/watch?v=JCX81eA6I24'
  },
  {
    id: 'hamstrings-db-rdl',
    name: 'Dumbbell Romanian Deadlift',
    muscle: 'hamstrings',
    equipment: 'dumbbell',
    difficulty: 'Beginner',
    targets: ['Hamstrings', 'Glutes', 'Lower Back'],
    instructions: [
      'Stand holding a dumbbell in each hand, palms facing thighs.',
      'Hinge backward at your hips, sending your weight over the heels.',
      'Lower the weights along the front of your legs, keeping the core braced.',
      'Drive your hips back to upright once you reach maximum comfortable hamstring stretch.'
    ],
    proTip: 'Keep your chin tucked. Looking straight up at a mirror arches the neck, whereas keeping a neutral neck protects your spine.',
    imageUrl: 'https://images.unsplash.com/photo-1434608519344-49d77a699e1d?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://www.youtube.com/watch?v=_S0Z-OWe2wI'
  },
  {
    id: 'hamstrings-machine-curl',
    name: 'Seated Leg Curl Machine',
    muscle: 'hamstrings',
    equipment: 'machines',
    difficulty: 'Beginner',
    targets: ['Biceps Femoris (Hamstrings)', 'Gastrocnemius'],
    instructions: [
      'Adjust the machine back pad so your knees line up with the pivot axle.',
      'Securely snap the lap pad flat above your thighs.',
      'Contract your hamstrings to pull the ankle roller pad downwards under your seat.',
      'Slowly release the roller pad back to the top leg extension.'
    ],
    proTip: 'Keep your toes pulled up (dorsiflexed) to emphasize hamstring contraction rather than calf assistance.',
    imageUrl: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://www.youtube.com/watch?v=0mU6L_Hw0Z8'
  },

  // --- GLUTES ---
  {
    id: 'glutes-bb-thrust',
    name: 'Barbell Hip Thrust',
    muscle: 'glutes',
    equipment: 'barbell',
    difficulty: 'Intermediate',
    targets: ['Gluteus Maximus', 'Hamstrings', 'Adductors'],
    instructions: [
      'Sit on the floor with your upper back supported against a flat bench. Place a padded barbell over your hips.',
      'Bend knees and position feet flat on the floor, about shoulder-width apart.',
      'Drive through your heels, pushing your hips straight up vertically until your torso is parallel to the ground.',
      'Maintain a tucked chin, squeeze glutes hard at the top (hips extended), then slowly lower.'
    ],
    proTip: 'Ensure your shins are strictly vertical at the top of the lift. If they tilt forward, shift feet out; if they tilt back, pull feet closer.',
    imageUrl: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://www.youtube.com/watch?v=LM8LG_0gL-o'
  },
  {
    id: 'glutes-db-lunge',
    name: 'Dumbbell Walking Lunge',
    muscle: 'glutes',
    equipment: 'dumbbell',
    difficulty: 'Beginner',
    targets: ['Gluteus', 'Quadriceps', 'Hamstrings'],
    instructions: [
      'Stand with weights at your sides. Take a large step forward with your right leg.',
      'Lower your hips straight down until your rear knee hovering just above the floor and front thigh is parallel.',
      'Press through your front heel to stand up, bringing the back leg forward to take the next lunge step.'
    ],
    proTip: 'To hit glutes over quads, tilt your upper body slightly forward (15 degrees) during the lunge step and press strictly through the front heel.',
    imageUrl: 'https://images.unsplash.com/photo-1552674605-db6ffd4facb5?q=80&w=600&auto=format&fit=crop',
    youtubeUrl: 'https://www.youtube.com/watch?v=D7KaRcAnA9g'
  }
];
