export type MuscleGroup =
  | 'chest'
  | 'biceps'
  | 'abs'
  | 'quads'
  | 'shoulders'
  | 'forearms'
  | 'lats'
  | 'triceps'
  | 'hamstrings'
  | 'glutes'
  | 'calves'
  | 'traps'
  | 'lower-back';

export type Gender = 'male' | 'female';
export type ViewDirection = 'front' | 'back';

export type EquipmentType = 'all' | 'barbell' | 'dumbbell' | 'bodyweight' | 'machines' | 'stretches';

export interface Exercise {
  id: string;
  name: string;
  muscle: MuscleGroup;
  equipment: Omit<EquipmentType, 'all'>;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  targets: string[];
  instructions: string[];
  proTip?: string;
  videoPlaceholderUrl?: string; // We can show a visual loop or animation representing form
  youtubeUrl?: string;
  imageUrl?: string;
}

export interface MacroResult {
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
}

export type ActivityLevel = 'sedentary' | 'lightly-active' | 'moderately-active' | 'very-active' | 'extra-active';
export type FitnessGoal = 'cutting' | 'maintenance' | 'bulking';

export interface CalculatorInputs {
  age: number;
  gender: 'male' | 'female';
  weight: number; // in kg
  height: number; // in cm
  activity: ActivityLevel;
  goal: FitnessGoal;
}

export interface OneRepMaxResult {
  oneRepMax: number;
  percentages: { percentage: number; weight: number; reps: string; intensity: string }[];
}

export interface WorkoutItem {
  id: string;
  exerciseName: string;
  sets: { reps: number; weight: number }[];
}

export interface WorkoutRoutine {
  id: string;
  name: string;
  items: WorkoutItem[];
  createdAt: string;
}
