import React, { useState } from 'react';
import { MuscleGroup, EquipmentType, Gender, ViewDirection } from './types';
import { exercises } from './data/exercises';
import BodyMap from './components/BodyMap';
import Calculators from './components/Calculators';
import WorkoutPlanner from './components/WorkoutPlanner';
import BookingDialog from './components/BookingDialog';
import {
  Activity,
  Dumbbell,
  MapPin,
  Calendar,
  Layers,
  ChevronRight,
  BookOpen,
  TrendingUp,
  Instagram,
  Youtube,
  Facebook,
  Sparkles,
  Award,
  AlertTriangle,
  Zap,
  Play,
  Globe,
  Check,
  Clock,
  Users,
  MessageSquare
} from 'lucide-react';

// Media datasets are dynamically loaded from our centralized exercises database module


export default function App() {
  // State for Directory filtering
  const [selectedMuscle, setSelectedMuscle] = useState<MuscleGroup>('chest');
  const [equipmentFilter, setEquipmentFilter] = useState<EquipmentType>('all');
  const [gender, setGender] = useState<Gender>('male');
  const [view, setView] = useState<ViewDirection>('front');
  const [cardMediaMode, setCardMediaMode] = useState<Record<string, 'real' | '2d'>>({});

  // Interactive Brand State
  const [branchLocation, setBranchLocation] = useState<'Kathmandu'>('Kathmandu');
  const [bookingOpen, setBookingOpen] = useState(false);
  const [bookingType, setBookingType] = useState<'trial' | 'membership'>('trial');

  // Dynamic filter lists
  const filteredExercises = exercises.filter((ex) => {
    const matchesMuscle = ex.muscle === selectedMuscle;
    const matchesEquipment = equipmentFilter === 'all' || ex.equipment === equipmentFilter;
    return matchesMuscle && matchesEquipment;
  });

  const handleOpenBooking = (type: 'trial' | 'membership') => {
    setBookingType(type);
    setBookingOpen(true);
  };

  const handleSelectMuscle = (muscle: MuscleGroup) => {
    setSelectedMuscle(muscle);
    // Smooth scroll down to exercise dynamic results anchor
    const el = document.getElementById('exercise-results-anchor');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  // Generate CSS keyframe loops for exercise cards based on different exercises to show proper form visually
  const renderInteractiveFormAnim = (id: string, muscle: string, finalYoutubeUrl?: string) => {
    const isRealMode = cardMediaMode[id] !== '2d'; // Defaults to 'real'
    const exObj = exercises.find(e => e.id === id);
    const hasImage = !!exObj?.imageUrl;

    const innerContent = (
      <>
        {/* Toggle Controls (Top Bar) */}
        <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between z-30 pointer-events-auto">
          {/* Top-Left Badge: Floating matted gray text label reading "⚡ FORM LOOP" */}
          <div className="flex items-center gap-1 bg-[#1c1c1e]/90 backdrop-blur-md px-2.5 py-1 rounded text-[9px] font-mono font-extrabold text-[#FF6321] uppercase tracking-widest border border-white/10 shadow-md">
            <Zap className="w-2.5 h-2.5 text-[#FF6321] animate-pulse" />
            <span>⚡ FORM LOOP</span>
          </div>

          {/* Toggle buttons */}
          {hasImage && (
            <div className="flex bg-black/90 backdrop-blur-md rounded p-0.5 border border-white/10 overflow-hidden font-mono text-[9px] font-extrabold text-zinc-400 shadow-md gap-0.5">
              <button
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setCardMediaMode(prev => ({ ...prev, [id]: 'real' }));
                }}
                className={`px-1.5 py-0.5 cursor-pointer rounded transition-all ${
                  isRealMode 
                    ? 'bg-[#FF6321] text-black font-black' 
                    : 'hover:text-white'
                }`}
              >
                REAL
              </button>
              <button
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setCardMediaMode(prev => ({ ...prev, [id]: '2d' }));
                }}
                className={`px-1.5 py-0.5 cursor-pointer rounded transition-all ${
                  !isRealMode 
                    ? 'bg-[#FF6321] text-black font-black' 
                    : 'hover:text-white'
                }`}
              >
                2D
              </button>
            </div>
          )}
        </div>

        {/* --- REAL PHOTO VIEW --- */}
        {isRealMode && exObj?.imageUrl ? (
          <div className="relative w-full h-full">
            <img 
              src={exObj.imageUrl} 
              alt={exObj.name}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
              referrerPolicy="no-referrer"
            />
            {/* Dark gradient overlay at bottom for details */}
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/45 to-transparent flex flex-col justify-end p-3.5 pb-10 z-10">
              <span className="text-[9px] font-mono text-[#FF6321] uppercase tracking-wider font-extrabold">Evolve HD Form Demonstration</span>
              <span className="text-[10px] font-bold text-white tracking-tight line-clamp-1">{exObj.name} Form Tutorial</span>
            </div>
          </div>
        ) : (
          /* --- 2D / ANIMATED VIEW (FALLBACK OR EXPLICIT 2D CHOSEN) --- */
          <div className="flex flex-col items-center justify-center w-full h-full relative p-4 pb-10">
            
            {/* Squat Animation */}
            {muscle === 'quads' && (
              <div className="flex flex-col items-center mb-1">
                <div className="w-16 h-8 border-b-2 border-zinc-700 relative">
                  <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-6 h-12 bg-[#FF6321]/20 border-b-4 border-l-2 border-r-2 border-[#FF6321] rounded-b-sm animate-bounce" style={{ animationDuration: '2.5s' }} />
                </div>
                <span className="text-[10px] font-mono text-zinc-500 mt-4 uppercase">SQUAT DEPTH DRIVE</span>
              </div>
            )}

            {/* Arm Curl Animation */}
            {muscle === 'biceps' && (
              <div className="flex flex-col items-center mb-1">
                <div className="h-10 w-10 relative">
                  {/* Arm Rotator */}
                  <div className="absolute top-0 left-0 w-8 h-2 bg-zinc-700 rounded origin-left animate-spin" style={{ animationDuration: '8s' }} />
                  <div className="absolute top-0 left-0 w-2 h-2 bg-[#FF6321] rounded-full" />
                </div>
                <span className="text-[10px] font-mono text-zinc-500 mt-6 uppercase">JOINT RANGE ECCENTRIC</span>
              </div>
            )}

            {/* Deadlift / Back Animation */}
            {(muscle === 'lats' || muscle === 'hamstrings' || muscle === 'glutes' || muscle === 'lower-back') && (
              <div className="flex flex-col items-center mb-1">
                <div className="w-16 h-12 border-b border-zinc-800 flex items-end justify-center relative">
                  {/* Barbell lift */}
                  <div className="absolute bottom-0 w-12 h-0.5 bg-zinc-400 animate-bounce" style={{ animationDuration: '3s' }}>
                    <div className="absolute -left-1 -top-1.5 w-1.5 h-3.5 bg-zinc-500 rounded" />
                    <div className="absolute -right-1 -top-1.5 w-1.5 h-3.5 bg-zinc-500 rounded" />
                  </div>
                </div>
                <span className="text-[10px] font-mono text-zinc-500 mt-4 uppercase">POSTERIOR CHAIN STRETCH</span>
              </div>
            )}

            {/* Ab Wheel Rollout Animation */}
            {id === 'abs-ab-wheel-rollout' && (
              <div className="flex flex-col items-center justify-center relative h-full w-full mb-1">
                <div className="w-28 h-0.5 bg-zinc-800 relative">
                  {/* Rolling Wheel */}
                  <div
                    className="absolute -top-3 w-6 h-6 rounded-full border-2 border-dashed border-[#FF6321] bg-[#FF6321]/15 flex items-center justify-center"
                    style={{
                      animation: 'rollout-loop 3.5s ease-in-out infinite',
                      left: '0px'
                    }}
                  >
                    <div className="w-1.5 h-1.5 bg-white rounded-full animate-ping" />
                  </div>
                </div>
                <span className="text-[10px] font-mono text-zinc-500 mt-6 uppercase">EXTENSION & CONTRACTION CONTROLS</span>
              </div>
            )}

            {/* Hanging Leg Raise Animation */}
            {id === 'abs-hanging-leg-raise' && (
              <div className="flex flex-col items-center justify-center relative h-full w-full mb-1">
                <div className="w-16 h-1 bg-zinc-700 relative mb-1" />
                <div 
                  className="w-1 h-10 bg-zinc-650 origin-top relative rounded" 
                  style={{ animation: 'leg-raise-pivot 4s ease-in-out infinite' }}
                >
                  <div 
                    className="absolute bottom-0 left-0 w-8 h-1 bg-[#FF6321] origin-left rounded" 
                    style={{ animation: 'leg-angle 4s ease-in-out infinite' }} 
                  />
                </div>
                <span className="text-[10px] font-mono text-zinc-500 mt-4 uppercase">90° RECTUS ANGLE CONTROL</span>
              </div>
            )}

            {/* Cable Crunch Animation */}
            {id === 'abs-cable-crunch' && (
              <div className="flex flex-col items-center justify-center relative h-full w-full mb-1">
                <div className="w-3 h-3 bg-zinc-700 rounded-full mb-1 flex items-center justify-center">
                  <div className="w-1 h-1 bg-[#FF6321] rounded-full animate-ping" />
                </div>
                <div className="w-1 bg-zinc-800 rounded relative" style={{ height: '36px' }}>
                  <div 
                    className="absolute top-0 left-[-2px] w-2 bg-[#FF6321] rounded" 
                    style={{ animation: 'cable-crunch-pull 2.5s ease-in-out infinite' }} 
                  />
                </div>
                <span className="text-[10px] font-mono text-zinc-500 mt-4 uppercase">SPINAL FLEXION FORCE</span>
              </div>
            )}

            {/* Core Default Fallback details */}
            {muscle !== 'quads' && 
             muscle !== 'biceps' && 
             muscle !== 'lats' && 
             muscle !== 'hamstrings' && 
             muscle !== 'glutes' && 
             muscle !== 'lower-back' && 
             id !== 'abs-ab-wheel-rollout' && 
             id !== 'abs-hanging-leg-raise' && 
             id !== 'abs-cable-crunch' && (
              <div className="flex flex-col items-center space-y-2 mb-1">
                <Dumbbell className="w-8 h-8 text-[#FF6321]/60 animate-spin" style={{ animationDuration: '12s' }} />
                <span className="text-[10px] font-mono text-zinc-500 uppercase">EVOLVE VERIFIED TECHNIQUE</span>
              </div>
            )}

          </div>
        )}

        {/* Center Hover Overlay: Semi-transparent mask with a white play icon */}
        {finalYoutubeUrl && (
          <div className="absolute inset-0 bg-black/65 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center z-20 pointer-events-none">
            <div className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/50 text-white shadow-xl scale-90 group-hover:scale-100 transition-transform duration-350">
              <Play className="w-5 h-5 text-white fill-current ml-0.5" />
            </div>
          </div>
        )}

        {/* Bottom Accent Bar: Reads "TAP TO WATCH FULL VIDEO" */}
        <div className="absolute bottom-0 left-0 right-0 bg-black/85 backdrop-blur-sm border-t border-white/5 py-2.5 text-center text-[10px] font-mono tracking-widest font-extrabold text-zinc-400 group-hover:text-[#FF6321] transition-colors z-25 uppercase flex items-center justify-center gap-1.5">
          <Play className="w-3 h-3 text-white fill-current" />
          <span>TAP TO WATCH FULL VIDEO</span>
        </div>
      </>
    );

    const exName = exObj ? exObj.name : 'exercise';
    const targetUrl = finalYoutubeUrl || `https://www.youtube.com/@gymbody/videos`;

    return (
      <a 
        href={targetUrl}
        target="_blank"
        rel="noreferrer"
        className="relative w-full h-48 bg-black rounded-xl overflow-hidden flex flex-col items-center justify-center border border-white/5 group hover:border-[#FF6321]/30 transition-all duration-300 shadow-inner block cursor-pointer select-none"
        id={`exercise-loop-container-${id}`}
        title={`Click to watch professional techique loop on YouTube for ${exName}`}
      >
        {innerContent}
      </a>
    );
  };

  return (
    <div className="min-h-screen bg-[#111111] text-white font-sans selection:bg-[#FF6321] selection:text-black" id="evolve-fitness-app-root">

      {/* --- HEADER / NAVIGATION --- */}
      <header className="sticky top-0 z-40 bg-[#1c1c1e]/95 backdrop-blur-md border-b border-white/10" id="evolve-header">
        <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-[#FF6321] to-[#e55a1e] flex items-center justify-center shadow-lg shadow-[#FF6321]/20">
              <Dumbbell className="w-5 h-5 text-black transform -rotate-45" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-black tracking-tighter text-[#FF6321] uppercase font-display">
                EVOLVE <span className="text-white">FITNESS</span>
              </span>
              <span className="text-[9px] font-mono tracking-widest text-[#FF6321]/80 uppercase -mt-1 font-black">
                Form over ego
              </span>
            </div>
          </div>

          {/* Directory Navigation Links */}
          <nav className="hidden md:flex items-center gap-4 lg:gap-6 text-xs font-mono font-bold tracking-wider text-gray-400">
            <a href="#interactive-body-map-section" className="hover:text-white transition">TRAINING DICT</a>
            <a href="#fitness-calculators-section" className="hover:text-white transition flex items-center gap-1">
              <span>CALCULATORS</span>
              <span className="h-1.5 w-1.5 rounded-full bg-[#FF6321]" />
            </a>
            <a 
              href="#exercise-results-anchor" 
              onClick={(e) => {
                e.preventDefault();
                const el = document.getElementById('exercise-results-anchor');
                if (el) {
                  el.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
              }}
              className="text-gray-455 hover:text-white transition flex items-center gap-1"
              title="View Exercise Database"
            >
              <Youtube className="w-3.5 h-3.5" />
              <span>EXERCISE</span>
            </a>
            <a href="#gym-membership-section" className="hover:text-white transition">MEMBERSHIPS</a>
            <a href="#branch-locations-section" className="hover:text-white transition">BRANCH HOURS</a>
          </nav>

          {/* Location Dropdown & CTA */}
          <div className="flex items-center gap-3">
            {/* Nepal Location Selector */}
            <a 
              href="https://www.google.com/maps/search/?api=1&query=Evolve+Fitness+Thamel+Kathmandu+Nepal" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 bg-[#1c1c1e] hover:bg-[#2c2c2e] border border-white/5 hover:border-[#FF6321]/30 px-3.5 py-2 rounded-lg shrink-0 transition-all cursor-pointer group"
              title="Open Kathmandu Thamel location on Google Maps"
            >
              <MapPin className="w-3.5 h-3.5 text-[#FF6321] group-hover:scale-110 transition-transform" />
              <select
                value={branchLocation}
                readOnly
                className="bg-transparent text-xs font-mono font-bold text-gray-300 focus:outline-none pointer-events-none cursor-pointer"
                id="location-switcher-select"
              >
                <option value="Kathmandu" className="bg-[#111111]">KTM Thamel ↗</option>
              </select>
            </a>

            <button
              onClick={() => handleOpenBooking('trial')}
              className="hidden sm:inline-flex bg-[#FF6321] hover:bg-[#e55a1e] text-black text-xs font-bold tracking-wider px-6 py-2.5 rounded uppercase transition-colors font-sans"
              id="join-online-cta-header"
            >
              Join Online
            </button>
          </div>
        </div>
      </header>

      {/* --- HERO SECTION --- */}
      <section className="relative pt-12 pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto overflow-hidden text-center" id="interactive-body-map-section">
        
        {/* Decorative dynamic ambient points */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#FF6321]/5 rounded-full blur-[140px] pointer-events-none" />

        <div className="max-w-3xl mx-auto space-y-4 mb-12">
          <div className="inline-flex items-center gap-2 bg-[#FF6321]/10 px-4 py-1.5 rounded-full border border-[#FF6321]/20">
            <Sparkles className="w-3.5 h-3.5 text-[#FF6321]" />
            <span className="text-[10px] font-mono tracking-widest text-[#FF6321] font-bold uppercase">
              ZERO FRICTION WORKOUT TUNING
            </span>
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tight text-white uppercase font-display leading-[1.05] max-w-2xl mx-auto">
            EVOLVE YOUR FORM. <br />
            <span className="bg-gradient-to-r from-white via-gray-250 to-[#FF6321] bg-clip-text text-transparent">
              SELECT A MUSCLE.
            </span>
          </h1>

          <p className="text-gray-400 text-xs sm:text-sm max-w-xl mx-auto leading-relaxed font-light">
            Skip the bloated commercial tutorials. Select a target muscle cluster on our visual anatomical model and filter by your equipment type to instantly parse proper mechanical form.
          </p>
        </div>

        {/* Anatomical Engine body map */}
        <div className="mb-20">
          <BodyMap
            selectedMuscle={selectedMuscle}
            onSelectMuscle={handleSelectMuscle}
            gender={gender}
            setGender={setGender}
            view={view}
            setView={setView}
          />
        </div>

        {/* Dynamic Exercise Results Anchor */}
        <hr className="border-white/5 mb-16" id="exercise-results-anchor" />

        {/* --- DYNAMIC TUTORIALS SECTION --- */}
        <div className="text-left space-y-8">
          
          {/* Header of exercise directory & Dropdown Filtering Bar */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-white/5 pb-5">
            <div>
              <div className="flex items-center gap-2 text-gray-500 font-mono text-xs">
                <BookOpen className="w-4 h-4 text-[#FF6321]" />
                <span className="capitalize text-white font-black">{selectedMuscle.replace('-', ' ')} Exercises</span>
                <span>•</span>
                <span className="capitalize">{equipmentFilter === 'all' ? 'All Equipment' : equipmentFilter} Protocols</span>
              </div>
              <h2 className="text-2xl font-extrabold text-white tracking-tight uppercase mt-1">
                Exercise Protocols
              </h2>
            </div>

            {/* Equipment Filter Strip (Equipment-specific filter) */}
            <div className="flex flex-wrap items-center gap-1.5">
              {(['all', 'barbell', 'dumbbell', 'bodyweight', 'machines', 'stretches'] as EquipmentType[]).map((eq) => (
                <button
                  key={eq}
                  onClick={() => setEquipmentFilter(eq)}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-bold tracking-wider border transition-all ${
                    equipmentFilter === eq
                      ? 'bg-[#FF6321]/10 border-[#FF6321] text-[#FF6321] rounded bg-white/5 uppercase'
                      : 'bg-[#1c1c1e] border-white/10 text-gray-500 hover:border-gray-700 hover:text-white uppercase'
                  }`}
                  id={`equipment-filter-${eq}`}
                >
                  {eq.toUpperCase()}
                </button>
              ))}
            </div>
          </div>

          {/* Grid list of exercise components matched with layout requirements */}
          {filteredExercises.length === 0 ? (
            <div className="py-16 text-center bg-[#1c1c1e] rounded-2xl border border-white/5 max-w-xl mx-auto space-y-3">
              <AlertTriangle className="w-10 h-10 text-amber-500 mx-auto" />
              <h4 className="text-white text-sm font-bold uppercase font-mono">No specific matches found</h4>
              <p className="text-gray-500 text-xs px-6 leading-relaxed max-w-md mx-auto">
                We've filtered {selectedMuscle.replace('-', ' ')} with '{equipmentFilter}'. Pick other equipment filters like **stretches**, **bodyweight**, or the visual body map to explore alternative routines!
              </p>
              <button
                onClick={() => setEquipmentFilter('all')}
                className="inline-flex py-1.5 px-4 rounded bg-zinc-800 text-white text-[11px] font-mono hover:bg-zinc-700 transition"
                id="reset-equipment-filter-button"
              >
                Reset Equipment Filter
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-12" id="exercise-cards-grid">
              {filteredExercises.map((ex) => {
                return (
                  <div
                    key={ex.id}
                    className="bg-[#1c1c1e] border border-white/5 rounded-2xl p-5 flex flex-col gap-6 hover:border-white/10 transition-all duration-300"
                    id={`exercise-card-${ex.id}`}
                  >
                    {/* 1. CLICKABLE LINK AREA - BOUND TO YOUTUBE VIDEO URL */}
                    <div id={`clickable-media-section-${ex.id}`}>
                      {renderInteractiveFormAnim(ex.id, ex.muscle, ex.youtubeUrl)}
                    </div>

                    {/* 2. CARD META SECTION */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/5 pb-4" id={`meta-section-${ex.id}`}>
                      <h3 className="text-lg font-black text-white tracking-tight leading-snug">
                        {ex.name}
                      </h3>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className={`text-[9px] font-mono font-extrabold px-2.5 py-1 rounded uppercase tracking-wider ${
                          ex.difficulty === 'Beginner'
                            ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20'
                            : ex.difficulty === 'Intermediate'
                            ? 'bg-yellow-500/15 text-yellow-500 border border-yellow-500/20'
                            : 'bg-red-500/15 text-red-500 border border-red-500/30'
                        }`}>
                          {ex.difficulty.toUpperCase()}
                        </span>
                        <span className="text-[9px] font-mono text-zinc-400 bg-black/60 px-2.5 py-1 rounded border border-white/5 uppercase tracking-wider font-extrabold">
                          {ex.equipment.toUpperCase()}
                        </span>
                      </div>
                    </div>

                    {/* 3. CONTENT TARGETS SECTION */}
                    <div className="border-b border-white/5 pb-4" id={`targets-section-${ex.id}`}>
                      <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest block mb-2 font-black">
                        KINETIC LOAD TARGETS
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {ex.targets.map((tg) => (
                          <span key={tg} className="text-[10px] text-zinc-300 bg-black/40 border border-white/5 px-2.5 py-1 rounded font-mono uppercase tracking-wider font-extrabold">
                            {tg}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* 4. PROTOCOL INSTRUCTIONS SECTION */}
                    <div className="space-y-3" id={`instructions-section-${ex.id}`}>
                      <div className="border-b border-white/5 pb-2">
                        <span className="text-[10px] font-mono tracking-widest text-[#FF6321] uppercase block font-black">
                          INSTRUCTION PROTOCOL
                        </span>
                      </div>
                      <ol className="space-y-2.5">
                        {ex.instructions.map((step, idx) => (
                          <li key={idx} className="text-xs text-zinc-300 leading-relaxed flex items-start gap-3">
                            <span className="font-mono text-[10px] font-bold text-[#FF6321] bg-[#FF6321]/5 border border-[#FF6321]/20 h-5 w-5 rounded-full flex items-center justify-center shrink-0 mt-0.5">
                              {idx + 1}
                            </span>
                            <span className="pt-0.5">{step}</span>
                          </li>
                        ))}
                      </ol>
                    </div>

                    {/* Custom Pro tip block (bottom) */}
                    {ex.proTip && (
                      <div className="bg-black/35 border border-white/5 rounded-xl p-3.5 flex items-start gap-2.5 mt-auto" id={`protip-container-${ex.id}`}>
                        <Sparkles className="w-4 h-4 text-[#FF6321] shrink-0 mt-0.5" />
                        <div>
                          <span className="text-[9px] font-mono text-[#FF6321] font-bold uppercase block tracking-wider">
                            Form Pro Tip
                          </span>
                          <p className="text-[11px] text-zinc-400 leading-normal mt-0.5 font-light">
                            {ex.proTip}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
              );})}
            </div>
          )}
        </div>
      </section>      {/* --- MIDDLE BRAND INTEGRATION --- */}
      <section className="bg-[#111111] border-t border-b border-white/5 py-16 px-4 sm:px-6 lg:px-8 mt-4" id="gym-membership-section">
        <div className="w-full max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          
          <div className="space-y-4">
            <div className="inline-flex items-center gap-1.5 text-gray-400 font-mono text-xs">
              <Award className="w-4 h-4 text-[#FF6321]" />
              <span>THE ELITE IRON STANDARD</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight uppercase font-display leading-[1.1]">
              Mastered the form? <br />
              Now push the weight.
            </h2>
            <p className="text-gray-400 text-xs sm:text-sm leading-relaxed font-light">
              Our world-class Evolve Fitness facilities feature industry-certified Eleiko competition barbells, calibrated steel plates, Hammer Strength selectorized pin machines, and solid lifters with zero ego. Take your technical knowledge to the physical floor.
            </p>
            
            {/* CTAs */}
            <div className="flex flex-wrap gap-3 pt-4">
              <button
                onClick={() => handleOpenBooking('trial')}
                className="py-3 px-6 rounded bg-[#FF6321] hover:bg-[#e55a1e] text-black text-xs font-bold uppercase tracking-wider transition-colors font-sans"
                id="trial-banner-book-button"
              >
                Book a Free Trial Session
              </button>
              <button
                onClick={() => handleOpenBooking('membership')}
                className="py-3 px-6 rounded bg-black hover:bg-[#2c2c2e] text-white text-xs font-bold uppercase tracking-wider border border-white/10 transition-colors font-sans"
                id="plans-banner-view-button"
              >
                View Membership Plans
              </button>
            </div>
          </div>

          {/* Graphical brand display block */}
          <div className="relative p-6 rounded-2xl bg-[#1c1c1e] border border-white/5 flex flex-col justify-between overflow-hidden group">
            <div className="absolute top-0 right-0 w-64 h-64 bg-[#FF6321]/5 rounded-full blur-[80px]" />
            <div className="flex justify-between items-start mb-6">
              <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest font-black">
                VERIFIED FACILITIES
              </span>
              <span className="h-2 w-2 rounded-full bg-emerald-500 animate-ping" />
            </div>

            <div className="space-y-4 relative z-10">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-black p-3 rounded-lg border border-white/5">
                  <span className="text-lg font-black text-[#FF6321] font-mono">15+</span>
                  <p className="text-[10px] text-gray-400 font-mono uppercase mt-0.5">Heavy Load Platforms</p>
                </div>
                <div className="bg-black p-3 rounded-lg border border-white/5">
                  <span className="text-lg font-black text-white font-mono">Eleiko</span>
                  <p className="text-[10px] text-gray-400 font-mono uppercase mt-0.5">Steel Competitions</p>
                </div>
              </div>

              <div className="bg-black/40 p-3.5 rounded-lg border border-white/5">
                <div className="text-xs font-semibold text-white">Kathmandu Gym Location</div>
                <p className="text-[10px] text-gray-500 leading-normal mt-1">
                  Our gym maintains a 24-rack lifting setup with custom shockwave absorption platforms for heavy lifts.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* --- GYM BODY MOTIVATION BANNER SECTION --- */}
      <section className="bg-black/40 border-b border-white/5 py-16 px-4 sm:px-6 lg:px-8" id="gym-body-motivation-section">
        <div className="w-full max-w-7xl mx-auto">
          <div className="bg-gradient-to-br from-[#1c1c1e] to-[#0f0f10] border border-white/5 rounded-3xl p-8 sm:p-12 relative overflow-hidden group shadow-2xl">
            {/* Ambient abstract glow */}
            <div className="absolute top-0 right-0 w-96 h-96 bg-[#FF6321]/5 rounded-full blur-[120px] pointer-events-none group-hover:bg-[#FF6321]/10 transition-colors duration-500" />
            <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-red-500/5 rounded-full blur-[100px] pointer-events-none" />

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center relative z-10">
              {/* Content box */}
              <div className="lg:col-span-5 space-y-5 text-left">
                <div className="inline-flex items-center gap-2 bg-[#FF6321]/15 px-3 py-1 rounded-full border border-[#FF6321]/20">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-[#FF6321]"></span>
                  </span>
                  <span className="text-[10px] font-mono tracking-widest text-[#FF6321] font-extrabold uppercase">
                    OFFICIAL PARTNER STREAM
                  </span>
                </div>

                <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white uppercase font-display leading-[1.1]">
                  GYM BODY <br />
                  <span className="text-[#FF6321]">MOTIVATION</span>
                </h2>

                <p className="text-gray-400 text-xs sm:text-sm leading-relaxed font-light">
                  Fuel your drive before you attack the heavy racks. Sync with relentless iron work ethic, premium bodybuilding content, and raw power lifts. Stream directly from the gym's motivational partner to cultivate absolute focus.
                </p>

                <div className="pt-3">
                  <a
                    href="https://www.youtube.com/@gymbody/videos"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 bg-[#FF6321] hover:bg-[#e55a1e] text-black text-xs font-bold tracking-wider px-6 py-3 rounded-xl uppercase transition-all transform hover:translate-y-[-1px] font-sans shadow-lg shadow-[#FF6321]/10"
                    id="gymbody-youtube-cta-btn"
                  >
                    <Youtube className="w-4 h-4 fill-current text-black" />
                    <span>LAUNCH MOTIVATION HUB</span>
                  </a>
                </div>
              </div>

              {/* High-Fi visual interactive video grid */}
              <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-4">
                {/* Visual Video Card 1 */}
                <a
                  href="https://www.youtube.com/@gymbody/videos"
                  target="_blank"
                  rel="noreferrer"
                  className="bg-black/50 border border-white/5 rounded-2xl p-4 flex flex-col justify-between hover:border-[#FF6321]/30 hover:bg-black/80 transition-all duration-300 group/card cursor-pointer"
                >
                  <div className="aspect-[4/3] bg-zinc-900 rounded-lg relative overflow-hidden flex items-center justify-center">
                    <img 
                      src="https://images.unsplash.com/photo-1517838277536-f5f99be501cd?q=80&w=400&auto=format&fit=crop" 
                      alt="Gym motivation" 
                      className="w-full h-full object-cover opacity-60 group-hover/card:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                    <div className="absolute w-9 h-9 rounded-full bg-[#FF6321]/20 border border-[#FF6321]/40 flex items-center justify-center group-hover/card:bg-[#FF6321] group-hover/card:text-black transition-colors duration-300">
                      <Play className="w-3.5 h-3.5 fill-current ml-0.5 text-white group-hover/card:text-black" />
                    </div>
                  </div>
                  <div className="mt-3 text-left">
                    <span className="text-[9px] font-mono font-bold text-gray-500 uppercase tracking-widest block">RAW HYPERTROPHY</span>
                    <h3 className="text-xs font-bold text-white mt-1 group-hover/card:text-[#FF6321] transition-colors leading-tight">PRE-WORKOUT ENERGY</h3>
                  </div>
                </a>

                {/* Visual Video Card 2 */}
                <a
                  href="https://www.youtube.com/@gymbody/videos"
                  target="_blank"
                  rel="noreferrer"
                  className="bg-black/50 border border-white/5 rounded-2xl p-4 flex flex-col justify-between hover:border-[#FF6321]/30 hover:bg-black/80 transition-all duration-300 group/card cursor-pointer"
                >
                  <div className="aspect-[4/3] bg-zinc-900 rounded-lg relative overflow-hidden flex items-center justify-center">
                    <img 
                      src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=400&auto=format&fit=crop" 
                      alt="Heavy Lift Motivation" 
                      className="w-full h-full object-cover opacity-60 group-hover/card:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                    <div className="absolute w-9 h-9 rounded-full bg-[#FF6321]/20 border border-[#FF6321]/40 flex items-center justify-center group-hover/card:bg-[#FF6321] group-hover/card:text-black transition-colors duration-300">
                      <Play className="w-3.5 h-3.5 fill-current ml-0.5 text-white group-hover/card:text-black" />
                    </div>
                  </div>
                  <div className="mt-3 text-left">
                    <span className="text-[9px] font-mono font-bold text-gray-500 uppercase tracking-widest block">IRON SPIRIT</span>
                    <h3 className="text-xs font-bold text-white mt-1 group-hover/card:text-[#FF6321] transition-colors leading-tight">LIMIT BREAKERS</h3>
                  </div>
                </a>

                {/* Visual Video Card 3 */}
                <a
                  href="https://www.youtube.com/@gymbody/videos"
                  target="_blank"
                  rel="noreferrer"
                  className="bg-black/50 border border-white/5 rounded-2xl p-4 flex flex-col justify-between hover:border-[#FF6321]/30 hover:bg-black/80 transition-all duration-300 group/card cursor-pointer"
                >
                  <div className="aspect-[4/3] bg-zinc-900 rounded-lg relative overflow-hidden flex items-center justify-center">
                    <img 
                      src="https://images.unsplash.com/photo-1605296867424-35fc25c9507d?q=80&w=400&auto=format&fit=crop" 
                      alt="Pro Workout" 
                      className="w-full h-full object-cover opacity-60 group-hover/card:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                    <div className="absolute w-9 h-9 rounded-full bg-[#FF6321]/20 border border-[#FF6321]/40 flex items-center justify-center group-hover/card:bg-[#FF6321] group-hover/card:text-black transition-colors duration-300">
                      <Play className="w-3.5 h-3.5 fill-current ml-0.5 text-white group-hover/card:text-black" />
                    </div>
                  </div>
                  <div className="mt-3 text-left">
                    <span className="text-[9px] font-mono font-bold text-gray-500 uppercase tracking-widest block">MINDSET SHIFT</span>
                    <h3 className="text-xs font-bold text-white mt-1 group-hover/card:text-[#FF6321] transition-colors leading-tight">EGO DESTRUCTION</h3>
                  </div>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* --- UTILITY TOOLS SECTION --- */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto" id="fitness-calculators-section">
        <div className="mb-10 text-center max-w-xl mx-auto space-y-2">
          <span className="text-xs font-mono font-bold text-[#FF6321] tracking-widest uppercase block">
            ANATOMICAL MULTITOOLS
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-display uppercase">
            ESTIMATE, TARGET, AND OPTIMIZE
          </h2>
          <p className="text-gray-500 text-xs leading-normal font-light">
            Complement your form mapping with verified daily caloric breakdown charts and automated repetitions limits calculation blocks.
          </p>
        </div>

        {/* Dynamic Calculators Panel */}
        <div className="mb-16">
          <Calculators />
        </div>

        {/* Workout Plan Split Builder */}
        <div className="pt-8">
          <WorkoutPlanner />
        </div>
      </section>

      {/* --- FOOTER / UTILITY & AREA --- */}
      <footer className="bg-black border-t border-white/5 pt-16 pb-8 text-gray-400 px-4 sm:px-6 lg:px-8" id="branch-locations-section">
        <div className="w-full max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
          
          {/* Col 1: Bio */}
          <div className="space-y-4">
            <span className="text-sm font-black tracking-tighter text-white uppercase font-display">
              EVOLVE <span className="text-[#FF6321]">FITNESS</span>
            </span>
            <p className="text-xs text-gray-500 leading-relaxed font-light">
              The ultimate high-performance training facility in Nepal. Tailored specifically for pure bodybuilders, powerlifters, and athletes wanting precise mechanical progression.
            </p>
            <div className="flex items-center gap-3 pt-2">
              <a href="https://www.instagram.com/evolve_fitness_nepal/" target="_blank" rel="noreferrer" className="hover:text-[#FF6321] transition" title="Evolve Fitness Instagram">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="https://www.youtube.com/@gymbody/videos" target="_blank" rel="noreferrer" className="hover:text-[#FF6321] transition" title="Gym Body Motivation Channel">
                <Youtube className="w-4 h-4" />
              </a>
              <a href="https://www.facebook.com/evolvefitnessnepal/" target="_blank" rel="noreferrer" className="hover:text-[#FF6321] transition" title="Evolve Fitness Facebook">
                <Facebook className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Col 2: Directory */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono font-bold tracking-wider text-white uppercase">
              PORTAL DIRECTORY
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#interactive-body-map-section" className="text-gray-500 hover:text-white transition flex items-center gap-1.5">
                  <ChevronRight className="w-3 h-3 text-[#FF6321]" />
                  <span>Anatomy Body Map</span>
                </a>
              </li>
              <li>
                <a href="#fitness-calculators-section" className="text-gray-500 hover:text-white transition flex items-center gap-1.5">
                  <ChevronRight className="w-3 h-3 text-[#FF6321]" />
                  <span>Macro Calorie Calculator</span>
                </a>
              </li>
              <li>
                <a href="#fitness-calculators-section" className="text-gray-500 hover:text-white transition flex items-center gap-1.5">
                  <ChevronRight className="w-3 h-3 text-[#FF6321]" />
                  <span>One-Rep Max Estimator</span>
                </a>
              </li>
              <li>
                <a href="#fitness-calculators-section" className="text-gray-500 hover:text-white transition flex items-center gap-1.5">
                  <ChevronRight className="w-3 h-3 text-[#FF6321]" />
                  <span>Custom Schedule Planner</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Kathmandu Location */}
          <div className="space-y-3 font-mono text-xs">
            <h4 className="text-xs font-mono font-bold tracking-wider text-white uppercase">
              📍 KATHMANDU Thamel
            </h4>
            <div className="text-gray-500 space-y-1 font-light leading-snug">
              <p className="text-white font-semibold">Thamel Chok Rig Terminal</p>
              <p>Kathmandu, Nepal</p>
              <p className="pt-2 text-[10px]">📞 +977-1-4700002</p>
              <p className="text-[10px]">⏰ Daily: 5:00 AM - 11:00 PM</p>
              <p className="pt-2">
                <a 
                  href="https://www.google.com/maps/search/?api=1&query=Evolve+Fitness+Thamel+Kathmandu+Nepal"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#FF6321] hover:underline hover:text-[#e55a1e] font-bold text-[11px] uppercase tracking-wider block"
                >
                  View on Google Maps ↗
                </a>
              </p>
            </div>
          </div>
        </div>

        <hr className="border-white/5 my-10" />

        <div className="w-full max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between text-[11px] text-gray-600 font-mono">
          <span>© 2026 Evolve Fitness Nepal. All Rights Reserved.</span>
          <span className="mt-2 sm:mt-0">Formulated with premium athletic principles.</span>
        </div>
      </footer>

      {/* Interactive Global dialog for Trial Session and Membership signup */}
      <BookingDialog
        isOpen={bookingOpen}
        onClose={() => setBookingOpen(false)}
        initialType={bookingType}
      />

      {/* Floating WhatsApp Action Button (Feature 6) */}
      <a
        href="https://wa.me/9779801201202?text=Hi%20Evolve%20Fitness%20Lazimpat!%20I%20have%20a%20question%20regarding%20schedules,%20training,%20or%20booking%20a%20session."
        target="_blank"
        rel="noreferrer"
        className="fixed bottom-6 right-6 z-50 bg-[#25D366] hover:bg-[#128C7E] text-white p-3.5 rounded-full shadow-2xl flex items-center justify-center border-2 border-white/10 hover:scale-105 active:scale-95 transition-all group pointer-events-auto"
        title="Direct chat with Evolve Fitness Lazimpat reception desk"
        id="floating-whatsapp-widget"
      >
        <MessageSquare className="w-6 h-6 fill-current text-white" />
        
        {/* Hover label */}
        <span className="max-w-0 overflow-hidden group-hover:max-w-xs group-hover:ml-2 text-xs font-mono font-extrabold text-black uppercase transition-all duration-350 ease-out whitespace-nowrap bg-white px-0 py-1 rounded group-hover:px-2 select-none">
          CHAT WITH ME
        </span>
      </a>
    </div>
  );
}
