import React, { useState, useMemo } from 'react';
import { CalculatorInputs, MacroResult, OneRepMaxResult, ActivityLevel, FitnessGoal } from '../types';
import { Calculator, Flame, Scale, Trophy, Zap, Compass, RefreshCw } from 'lucide-react';

export default function Calculators() {
  const [activeTab, setActiveTab] = useState<'macro' | 'one-rep'>('macro');

  // --- MACRO CALCULATOR STATE ---
  const [inputs, setInputs] = useState<CalculatorInputs>({
    age: 25,
    gender: 'male',
    weight: 75,
    height: 178,
    activity: 'moderately-active',
    goal: 'maintenance',
  });

  // --- ONE RET MAX STATE ---
  const [liftWeight, setLiftWeight] = useState<number>(100);
  const [liftReps, setLiftReps] = useState<number>(5);

  // --- MACRO CALCULATIONS ---
  const macroResults = useMemo<MacroResult>(() => {
    // Mifflin-St Jeor Equation
    let bmr = 0;
    if (inputs.gender === 'male') {
      bmr = 10 * inputs.weight + 6.25 * inputs.height - 5 * inputs.age + 5;
    } else {
      bmr = 10 * inputs.weight + 6.25 * inputs.height - 5 * inputs.age - 161;
    }

    // Activity multiplier
    const multipliers: Record<ActivityLevel, number> = {
      'sedentary': 1.2,
      'lightly-active': 1.375,
      'moderately-active': 1.55,
      'very-active': 1.725,
      'extra-active': 1.9,
    };

    const tdee = Math.round(bmr * multipliers[inputs.activity]);

    // Adjust for goals
    let targetCalories = tdee;
    if (inputs.goal === 'cutting') {
      targetCalories = Math.max(1200, tdee - 500);
    } else if (inputs.goal === 'bulking') {
      targetCalories = tdee + 400;
    }

    // Macros distribution
    // Protein: 2g/kg of body weight
    let proteinGrams = Math.round(inputs.weight * 2.0);
    if (inputs.goal === 'cutting') {
      proteinGrams = Math.round(inputs.weight * 2.2); // Preservation during cut
    }

    // Fats: 25% of target calories
    const fatCalories = targetCalories * 0.25;
    const fatGrams = Math.round(fatCalories / 9);

    // Carbs: Remaining calories
    const proteinCalories = proteinGrams * 4;
    const remainingCalories = targetCalories - (proteinCalories + fatCalories);
    const carbGrams = Math.round(Math.max(40, remainingCalories/4));

    return {
      calories: targetCalories,
      protein: proteinGrams,
      carbs: carbGrams,
      fats: fatGrams,
    };
  }, [inputs]);

  // --- ONE-REP MAX CALCULATIONS ---
  const oneRepMaxResults = useMemo<OneRepMaxResult>(() => {
    // Epley Formula: 1RM = w * (1 + r / 30)
    const orm = Math.round(liftWeight * (1 + liftReps / 30));

    const repsMapping = [
      { percentage: 100, reps: '1', intensity: 'Absolute limit', desc: 'Maximal Strength Development' },
      { percentage: 95, reps: '2', intensity: 'Extremely heavy', desc: 'Maximal Strength Development' },
      { percentage: 90, reps: '4', intensity: 'Heavy', desc: 'Strength & Power Adaptations' },
      { percentage: 85, reps: '6', intensity: 'Very challenging', desc: 'High Strength Hypertrophy' },
      { percentage: 80, reps: '8', intensity: 'Moderately heavy', desc: 'Optimal Muscle Growth Block' },
      { percentage: 75, reps: '10', intensity: 'Challenging', desc: 'Hypertrophy / Growth Focus' },
      { percentage: 70, reps: '12', intensity: 'Moderate', desc: 'Hypertrophy & Endurance mix' },
      { percentage: 65, reps: '15', intensity: 'Lighter', desc: 'Local Muscular Endurance' },
    ];

    const percentages = repsMapping.map((item) => ({
      percentage: item.percentage,
      weight: Math.round((orm * item.percentage) / 100),
      reps: item.reps,
      intensity: item.intensity,
    }));

    return {
      oneRepMax: orm,
      percentages,
    };
  }, [liftWeight, liftReps]);

  // Handle Macro Inputs
  const handleInput = (key: keyof CalculatorInputs, val: any) => {
    setInputs((prev) => ({ ...prev, [key]: val }));
  };

  const getGoalDescription = (goal: FitnessGoal) => {
    switch (goal) {
      case 'cutting':
        return 'Fat loss focus while preserving vital muscle tissue.';
      case 'maintenance':
        return 'Maintain weight, support cell repair, and optimize cellular energy.';
      case 'bulking':
        return 'Slight calorie surplus to fuel heavy training blocks and size increases.';
    }
  };

  return (
    <div className="w-full bg-[#1c1c1e] border border-white/5 p-6 md:p-8 rounded-2xl shadow-2xl relative overflow-hidden" id="evolve-calculators-root">
      
      {/* Decorative backdrop glow */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-[#FF6321]/5 rounded-full blur-[100px] pointer-events-none" />

      {/* Tabs Selector */}
      <div className="flex bg-black p-1 rounded-lg border border-white/10 mb-8 max-w-md mx-auto relative z-10 w-full">
        <button
          onClick={() => setActiveTab('macro')}
          className={`flex-1 flex items-center justify-center gap-2 py-3 rounded text-xs md:text-sm font-semibold tracking-wide transition-all duration-300 ${
            activeTab === 'macro'
              ? 'bg-[#FF6321] text-black font-black shadow shadow-[#FF6321]/20'
              : 'text-gray-400 hover:text-white'
          }`}
          id="tab-selector-macro"
        >
          <Flame className="w-4 h-4" />
          <span>Macro TDEE</span>
        </button>
        <button
          onClick={() => setActiveTab('one-rep')}
          className={`flex-1 flex items-center justify-center gap-2 py-3 rounded text-xs md:text-sm font-semibold tracking-wide transition-all duration-300 ${
            activeTab === 'one-rep'
              ? 'bg-[#FF6321] text-black font-black shadow shadow-[#FF6321]/20'
              : 'text-gray-400 hover:text-white'
          }`}
          id="tab-selector-one-rep"
        >
          <Trophy className="w-4 h-4" />
          <span>One-Rep Max</span>
        </button>
      </div>

      {activeTab === 'macro' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Inputs Section */}
          <div className="col-span-1 lg:col-span-5 space-y-5 bg-black/40 p-5 rounded-xl border border-white/5">
            <h3 className="text-base font-bold text-white tracking-wide border-b border-white/5 pb-2 flex items-center gap-2">
              <Compass className="w-4 h-4 text-[#FF6321]" />
              Physiological Metrics
            </h3>

            {/* Gender Toggle */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-mono text-gray-400">Biological Sex</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => handleInput('gender', 'male')}
                  className={`py-2 rounded text-xs font-semibold uppercase border transition-all ${
                    inputs.gender === 'male'
                      ? 'bg-black border-[#FF6321] text-[#FF6321] font-bold'
                      : 'bg-black border-white/5 text-gray-500 hover:text-white'
                  }`}
                  id="macro-sex-male"
                >
                  Male
                </button>
                <button
                  type="button"
                  onClick={() => handleInput('gender', 'female')}
                  className={`py-2 rounded text-xs font-semibold uppercase border transition-all ${
                    inputs.gender === 'female'
                      ? 'bg-black border-[#FF6321] text-[#FF6321] font-bold'
                      : 'bg-black border-white/5 text-gray-500 hover:text-white'
                  }`}
                  id="macro-sex-female"
                >
                  Female
                </button>
              </div>
            </div>

            {/* Grid of basic parameters */}
            <div className="grid grid-cols-3 gap-3">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-mono text-gray-400" htmlFor="macro-age-input">Age (yrs)</label>
                <input
                  type="number"
                  id="macro-age-input"
                  min="12"
                  max="100"
                  value={inputs.age}
                  onChange={(e) => handleInput('age', Math.max(1, parseInt(e.target.value) || 0))}
                  className="bg-black border border-white/10 px-3 py-2 rounded text-sm font-semibold text-white focus:outline-none focus:border-[#FF6321]"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-mono text-gray-400" htmlFor="macro-weight-input font-bold">Weight (kg)</label>
                <input
                  type="number"
                  id="macro-weight-input"
                  min="30"
                  max="300"
                  value={inputs.weight}
                  onChange={(e) => handleInput('weight', Math.max(1, parseInt(e.target.value) || 0))}
                  className="bg-black border border-white/10 px-3 py-2 rounded text-sm font-semibold text-white focus:outline-none focus:border-[#FF6321]"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-mono text-gray-400" htmlFor="macro-height-input">Height (cm)</label>
                <input
                  type="number"
                  id="macro-height-input"
                  min="100"
                  max="250"
                  value={inputs.height}
                  onChange={(e) => handleInput('height', Math.max(1, parseInt(e.target.value) || 0))}
                  className="bg-black border border-white/10 px-3 py-2 rounded text-sm font-semibold text-white focus:outline-none focus:border-[#FF6321]"
                />
              </div>
            </div>

            {/* Activity Level */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-mono text-gray-400" htmlFor="macro-activity-select">Training Activity Level</label>
              <select
                id="macro-activity-select"
                value={inputs.activity}
                onChange={(e) => handleInput('activity', e.target.value)}
                className="bg-black border border-white/10 px-3 py-2.5 rounded text-xs font-semibold text-white focus:outline-none focus:border-[#FF6321]"
              >
                <option value="sedentary">Sedentary (No training)</option>
                <option value="lightly-active">Lightly Active (1-2 days/wk training)</option>
                <option value="moderately-active">Moderately Active (3-5 days/wk high weight training)</option>
                <option value="very-active">Very Active (6-7 days/wk extreme coaching cycles)</option>
                <option value="extra-active">Extra Active (Professional athlete / Physical worker)</option>
              </select>
            </div>

            {/* Goal selection */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-mono text-gray-400">Ultimate Goal Target</label>
              <div className="grid grid-cols-3 gap-2">
                {(['cutting', 'maintenance', 'bulking'] as FitnessGoal[]).map((g) => (
                  <button
                    key={g}
                    type="button"
                    onClick={() => handleInput('goal', g)}
                    className={`py-2 px-1 rounded text-[10px] md:text-xs font-bold border transition-all uppercase ${
                      inputs.goal === g
                        ? 'bg-[#FF6321]/10 border-[#FF6321] text-[#FF6321]'
                        : 'bg-black border-white/5 text-gray-500 hover:text-white'
                    }`}
                    id={`goal-button-${g}`}
                  >
                    {g}
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-gray-500 leading-normal mt-1 font-light">
                {getGoalDescription(inputs.goal)}
              </p>
            </div>
          </div>

          {/* Results section */}
          <div className="col-span-1 lg:col-span-7 flex flex-col justify-between h-full bg-black/40 p-6 rounded-xl border border-white/5">
            <div>
              <div className="flex justify-between items-end border-b border-white/5 pb-4 mb-6">
                <div>
                  <span className="text-xs font-mono text-gray-500">YOUR OPTIMAL ENERGY CEILING</span>
                  <h4 className="text-3xl md:text-4xl font-extrabold text-[#FF6321] font-mono mt-1">
                    {macroResults.calories}{' '}
                    <span className="text-xs text-gray-400 font-sans tracking-wide font-normal">KCAL / DAY</span>
                  </h4>
                </div>
                <div className="bg-[#FF6321]/10 px-3 py-1.5 rounded border border-[#FF6321]/20 flex items-center gap-1.5">
                  <Flame className="w-3.5 h-3.5 text-[#FF6321]" />
                  <span className="text-[10px] font-bold text-[#FF6321] uppercase" id="nutrition-goal-badge">
                    {inputs.goal}
                  </span>
                </div>
              </div>

              {/* Macro Indicators */}
              <div className="space-y-4">
                {/* Protein */}
                <div>
                  <div className="flex justify-between items-center text-xs mb-1.5">
                    <span className="font-semibold text-white tracking-wide">🥩 PROTEIN (Building Blocks)</span>
                    <span className="font-mono font-bold text-emerald-400">
                      {macroResults.protein}g{' '}
                      <span className="text-[10px] text-gray-500 font-semibold uppercase">({macroResults.protein * 4} Cal)</span>
                    </span>
                  </div>
                  <div className="w-full bg-black rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-emerald-400 h-full rounded-full"
                      style={{
                        width: `${Math.min(100, ((macroResults.protein * 4) / macroResults.calories) * 100)}%`,
                      }}
                    />
                  </div>
                </div>

                {/* Carbohydrates */}
                <div>
                  <div className="flex justify-between items-center text-xs mb-1.5">
                    <span className="font-semibold text-white tracking-wide">🍚 CARBS (High-Octane Energy)</span>
                    <span className="font-mono font-bold text-amber-500">
                      {macroResults.carbs}g{' '}
                      <span className="text-[10px] text-gray-500 font-semibold uppercase">({macroResults.carbs * 4} Cal)</span>
                    </span>
                  </div>
                  <div className="w-full bg-black rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-[#FF6321] h-full rounded-full"
                      style={{
                        width: `${Math.min(100, ((macroResults.carbs * 4) / macroResults.calories) * 100)}%`,
                      }}
                    />
                  </div>
                </div>

                {/* Fats */}
                <div>
                  <div className="flex justify-between items-center text-xs mb-1.5">
                    <span className="font-semibold text-white tracking-wide">🥑 FATS (Hormones/Joint Protection)</span>
                    <span className="font-mono font-bold text-sky-400">
                      {macroResults.fats}g{' '}
                      <span className="text-[10px] text-gray-500 font-semibold uppercase">({macroResults.fats * 9} Cal)</span>
                    </span>
                  </div>
                  <div className="w-full bg-black rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-sky-400 h-full rounded-full"
                      style={{
                        width: `${Math.min(100, ((macroResults.fats * 9) / macroResults.calories) * 100)}%`,
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Food recommendations */}
            <div className="mt-8 pt-6 border-t border-white/5">
              <h5 className="text-[11px] font-mono font-bold tracking-widest text-[#FF6321] uppercase mb-3">
                🍳 RECOMMENDED CLEAN SOURCES
              </h5>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-black p-3 rounded border border-white/5">
                  <div className="text-xs text-zinc-300 font-semibold mb-0.5">Lean Fats</div>
                  <div className="text-[10px] text-gray-500 leading-tight">Whole Eggs, Salmon, Almonds, Avocados</div>
                </div>
                <div className="bg-black p-3 rounded border border-white/5">
                  <div className="text-xs text-zinc-300 font-semibold mb-0.5">High Carb</div>
                  <div className="text-[10px] text-gray-500 leading-tight">Oatmeal, White Rice, Sweet Potatoes, Bananas</div>
                </div>
                <div className="bg-black p-3 rounded border border-white/5">
                  <div className="text-xs text-zinc-300 font-semibold mb-0.5">Anabolic Pro</div>
                  <div className="text-[10px] text-gray-500 leading-tight">Chicken Breast, Whey, Egg Whites, Tofu</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'one-rep' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Inputs side */}
          <div className="col-span-1 lg:col-span-5 space-y-5 bg-black/40 p-5 rounded-xl border border-white/5">
            <h3 className="text-base font-bold text-white tracking-wide border-b border-white/5 pb-2 flex items-center gap-2">
              <Scale className="w-4 h-4 text-[#FF6321]" />
              ESTIMATE YOUR RAW INTENSITY
            </h3>

            {/* Weight lifted */}
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between items-center">
                <label className="text-xs font-mono text-gray-400" htmlFor="1rm-weight-input font-bold">Lifted Weight (kg)</label>
                <span className="text-[10px] text-gray-500">Standard Bar (20kg) included</span>
              </div>
              <input
                type="number"
                id="1rm-weight-input"
                min="1"
                max="500"
                value={liftWeight}
                onChange={(e) => setLiftWeight(Math.max(1, parseInt(e.target.value) || 0))}
                className="bg-black border border-white/10 px-3 py-3 rounded text-sm font-bold text-white focus:outline-none focus:border-[#FF6321]"
              />
            </div>

            {/* Repetitions */}
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between items-center">
                <label className="text-xs font-mono text-gray-400" htmlFor="1rm-reps-input">Completed Repetitions</label>
                <span className="text-[10px] font-mono text-[#FF6321]">Up to 12 reps optimal</span>
              </div>
              <input
                type="number"
                id="1rm-reps-input"
                min="1"
                max="30"
                value={liftReps}
                onChange={(e) => setLiftReps(Math.max(1, Math.min(30, parseInt(e.target.value) || 0)))}
                className="bg-black border border-white/10 px-3 py-3 rounded text-sm font-bold text-white focus:outline-none focus:border-[#FF6321]"
              />
              <div className="flex flex-wrap gap-1 mt-1.5">
                {[1, 3, 5, 8, 10, 12].map((r) => (
                  <button
                    key={r}
                    onClick={() => setLiftReps(r)}
                    className={`flex-1 py-1 rounded bg-black hover:bg-neutral-900 border border-white/5 text-[10px] font-mono text-gray-400 hover:text-white transition-all ${
                      liftReps === r ? 'border-[#FF6321] text-[#FF6321] bg-[#FF6321]/5' : ''
                    }`}
                    id={`rep-preset-${r}`}
                  >
                    {r} rep
                  </button>
                ))}
              </div>
            </div>

            {/* Explainer */}
            <p className="text-[11px] text-gray-500 leading-relaxed font-light">
              We leverage the proven **Epley Formula** used by high-performance powerlifters globally. Estimating 1RM relieves you of the structural risk of attempting a skeletal absolute limit under joint load.
            </p>
          </div>

          {/* Right outputs side */}
          <div className="col-span-1 lg:col-span-7 flex flex-col justify-between h-full bg-black/40 p-6 rounded-xl border border-white/5">
            <div>
              <div className="flex justify-between items-center border-b border-white/5 pb-4 mb-6">
                <div>
                  <span className="text-xs font-mono text-gray-500">ESTIMATED ONE-REP MAXIMUM</span>
                  <div className="flex items-baseline gap-2 mt-1">
                    <h4 className="text-4xl md:text-5xl font-extrabold text-[#FF6321] font-mono">
                      {oneRepMaxResults.oneRepMax}
                    </h4>
                    <span className="text-sm text-gray-400 font-mono">KG</span>
                  </div>
                </div>
                <div className="h-12 w-12 rounded bg-[#FF6321]/10 flex items-center justify-center border border-[#FF6321]/20">
                  <Zap className="w-5 h-5 text-[#FF6321] fill-[#FF6321]/10" />
                </div>
              </div>

              {/* Grid matrix table */}
              <div className="space-y-2.5">
                <div className="grid grid-cols-4 text-[10px] font-mono font-bold tracking-wider text-gray-500 uppercase pb-1 border-b border-white/5">
                  <span>INTENSITY</span>
                  <span>TARGET REPS</span>
                  <span className="text-right">WEIGHT</span>
                  <span className="text-right hidden sm:block">TRAINING FOCUS</span>
                </div>

                <div className="max-h-[240px] overflow-y-auto space-y-1.5 pr-1">
                  {oneRepMaxResults.percentages.map((p) => {
                    const isOptimal = p.percentage === 80 || p.percentage === 85;
                    return (
                      <div
                        key={p.percentage}
                        className={`grid grid-cols-4 items-center text-xs py-2 px-1.5 rounded border transition-all ${
                          isOptimal
                            ? 'bg-[#FF6321]/5 border-[#FF6321]/30 text-white'
                            : 'bg-black border-white/5 text-gray-400'
                        }`}
                        id={`intensity-row-${p.percentage}`}
                      >
                        <span className="font-mono font-semibold">{p.percentage}%</span>
                        <span className="font-mono">{p.reps} {parseInt(p.reps) === 1 ? 'rep' : 'reps'}</span>
                        <span className="font-mono text-right font-bold text-white pr-2">
                          {p.weight} <span className="text-[10px] text-gray-500">kg</span>
                        </span>
                        <span className="text-[10px] text-right text-gray-500 hidden sm:block italic font-light">
                          {p.percentage >= 90 ? 'Pure Neural' : p.percentage >= 75 ? 'Hypertrophy' : 'Endurance'}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="mt-5 text-[10px] text-gray-500 italic text-center font-light">
              💡 Pro Tip: For muscular growth, base your compound lifts strictly off 75-80% intensity for 8-10 slow repetitions.
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
