import React, { useState, useEffect } from 'react';
import { WorkoutRoutine, WorkoutItem } from '../types';
import { exercises } from '../data/exercises';
import { Plus, Trash2, Save, Download, FileText, CheckCircle2, ChevronRight, Play } from 'lucide-react';

export default function WorkoutPlanner() {
  const [routines, setRoutines] = useState<WorkoutRoutine[]>([]);
  const [currentRoutineName, setCurrentRoutineName] = useState<string>('My Evolve Schedule');
  const [selectedExerciseId, setSelectedExerciseId] = useState<string>(exercises[0].id);
  const [items, setItems] = useState<WorkoutItem[]>([]);
  const [notification, setNotification] = useState<string | null>(null);

  // Load existing routines from LocalStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem('evolve_routines');
      if (stored) {
        setRoutines(JSON.parse(stored));
      }
    } catch (e) {
      console.warn('Could not read from local storage', e);
    }
  }, []);

  // Save utility
  const saveToLocalStorage = (updated: WorkoutRoutine[]) => {
    try {
      localStorage.setItem('evolve_routines', JSON.stringify(updated));
      setRoutines(updated);
    } catch (e) {
      console.error('Failed storing routine', e);
    }
  };

  const triggerNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification(null);
    }, 3000);
  };

  // Add Exercise to List
  const handleAddItem = () => {
    const exercise = exercises.find((e) => e.id === selectedExerciseId);
    if (!exercise) return;

    // Check if item already exists
    if (items.some((i) => i.exerciseName === exercise.name)) {
      triggerNotification('Exercise already added.');
      return;
    }

    const newItem: WorkoutItem = {
      id: Math.random().toString(36).substring(2, 9),
      exerciseName: exercise.name,
      sets: [{ reps: 10, weight: 60 }], // default starting template
    };

    setItems([...items, newItem]);
    triggerNotification(`Added ${exercise.name}`);
  };

  // Add custom set to an exercise
  const handleAddSet = (itemId: string) => {
    setItems((prev) =>
      prev.map((item) => {
        if (item.id === itemId) {
          const lastSet = item.sets[item.sets.length - 1] || { reps: 10, weight: 60 };
          return {
            ...item,
            sets: [...item.sets, { reps: lastSet.reps, weight: lastSet.weight }],
          };
        }
        return item;
      })
    );
  };

  // Update set values
  const handleUpdateSet = (itemId: string, setIndex: number, key: 'reps' | 'weight', val: number) => {
    setItems((prev) =>
      prev.map((item) => {
        if (item.id === itemId) {
          const updatedSets = [...item.sets];
          updatedSets[setIndex] = {
            ...updatedSets[setIndex],
            [key]: val,
          };
          return { ...item, sets: updatedSets };
        }
        return item;
      })
    );
  };

  // Delete set or whole exercise item
  const handleDeleteSet = (itemId: string, setIndex: number) => {
    setItems((prev) =>
      prev.map((item) => {
        if (item.id === itemId) {
          const updatedSets = item.sets.filter((_, idx) => idx !== setIndex);
          return { ...item, sets: updatedSets };
        }
        return item;
      }).filter((item) => item.sets.length > 0)
    );
  };

  // Load a Prebuilt Evolve Template
  const handleLoadTemplate = (type: 'push' | 'pull' | 'legs') => {
    let selectedExercises: string[] = [];
    let name = '';

    if (type === 'push') {
      selectedExercises = ['chest-bb-press', 'chest-db-press', 'shoulders-bb-press', 'triceps-machine'];
      name = 'Evolve Champion Push Split';
    } else if (type === 'pull') {
      selectedExercises = ['lats-bb-row', 'lats-bodyweight', 'biceps-bb-curl', 'forearms-hang'];
      name = 'Titan Performance Pull Split';
    } else if (type === 'legs') {
      selectedExercises = ['quads-bb-squat', 'quads-machine-press', 'hamstrings-bb-deadlift', 'glutes-bb-thrust'];
      name = 'Savage Lower Quadrant split';
    }

    const loadedItems: WorkoutItem[] = selectedExercises.map((id) => {
      const ex = exercises.find((el) => el.id === id);
      return {
        id: Math.random().toString(36).substring(2, 9),
        exerciseName: ex ? ex.name : 'Squats',
        sets: [
          { reps: 12, weight: 60 },
          { reps: 10, weight: 80 },
          { reps: 8, weight: 100 },
        ],
      };
    });

    setItems(loadedItems);
    setCurrentRoutineName(name);
    triggerNotification(`Loaded template Split.`);
  };

  // Save routine
  const handleSaveRoutine = () => {
    if (items.length === 0) {
      triggerNotification('Add exercises first.');
      return;
    }

    const newRoutine: WorkoutRoutine = {
      id: Math.random().toString(36).substring(2, 9),
      name: currentRoutineName,
      items,
      createdAt: new Date().toLocaleDateString(),
    };

    const updated = [newRoutine, ...routines.filter((r) => r.name !== currentRoutineName)].slice(0, 5);
    saveToLocalStorage(updated);
    triggerNotification(`Routine saved.`);
  };

  // Load an existing saved routine
  const handleLoadSavedRoutine = (r: WorkoutRoutine) => {
    setCurrentRoutineName(r.name);
    setItems(r.items);
    triggerNotification(`Routine restored.`);
  };

  // Delete entire routine
  const handleDeleteRoutine = (id: string) => {
    const updated = routines.filter((r) => r.id !== id);
    saveToLocalStorage(updated);
    triggerNotification('Routine removed.');
  };

  // Export as configuration TXT
  const handleExportRoutine = () => {
    if (items.length === 0) return;

    let textContent = `====================================\n`;
    textContent += `    EVOLVE FITNESS CUSTOM ROUTINE\n`;
    textContent += `====================================\n`;
    textContent += `Routine Name: ${currentRoutineName}\n`;
    textContent += `Generated on: ${new Date().toLocaleDateString()}\n\n`;

    items.forEach((item, index) => {
      textContent += `${index + 1}. ${item.exerciseName}\n`;
      item.sets.forEach((set, sIdx) => {
        textContent += `   Set ${sIdx + 1}: ${set.reps} reps @ ${set.weight} kg\n`;
      });
      textContent += `\n`;
    });

    textContent += `Master your form, Evolve your standard.\n`;
    textContent += `Visit Evolve Fitness: Butwal & Kathmandu branches.`;

    const element = document.createElement('a');
    const file = new Blob([textContent], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = `${currentRoutineName.replace(/\s+/g, '_').toLowerCase()}_routine.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="w-full bg-[#1c1c1e] border border-white/5 p-6 md:p-8 rounded-2xl shadow-2xl relative" id="evolve-workout-planner-root">
      {/* Dynamic Status Notifications */}
      {notification && (
        <div className="absolute top-4 right-4 z-50 bg-[#FF6321] text-black px-4 py-2 rounded text-xs font-bold tracking-wide shadow-md flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>{notification}</span>
        </div>
      )}

      {/* Header and Templates */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-white/5 pb-5 mb-6 gap-4">
        <div>
          <span className="text-xs font-mono text-[#FF6321] uppercase tracking-wider">EVOLVE ROUTINE COMPANION</span>
          <h3 className="text-xl md:text-2xl font-extrabold text-white tracking-tight mt-1 font-display">
            Build Your Workout Split
          </h3>
          <p className="text-xs text-gray-500 mt-1 font-light">
            Compile individual targets, adjust sets, and track raw loads of your routine.
          </p>
        </div>

        {/* Rapid Templates */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[10px] font-mono text-gray-500 mr-1 uppercase">Load presets:</span>
          <button
            onClick={() => handleLoadTemplate('push')}
            className="px-3 py-1.5 rounded bg-black border border-white/10 text-gray-300 hover:border-[#FF6321] text-xs font-semibold cursor-pointer transition uppercase"
            id="template-push-loader"
          >
            Push
          </button>
          <button
            onClick={() => handleLoadTemplate('pull')}
            className="px-3 py-1.5 rounded bg-black border border-white/10 text-gray-300 hover:border-[#FF6321] text-xs font-semibold cursor-pointer transition uppercase"
            id="template-pull-loader"
          >
            Pull
          </button>
          <button
            onClick={() => handleLoadTemplate('legs')}
            className="px-3 py-1.5 rounded bg-black border border-white/10 text-gray-300 hover:border-[#FF6321] text-xs font-semibold cursor-pointer transition uppercase"
            id="template-legs-loader"
          >
            Legs
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Workspace Builder (Left 8 cols) */}
        <div className="lg:col-span-8 flex flex-col justify-between self-stretch bg-black/40 p-5 rounded-xl border border-white/5">
          <div>
            {/* Input fields to organize routine configuration */}
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="flex-1 flex flex-col gap-1.5">
                <label className="text-[10px] font-mono tracking-widest text-gray-500 uppercase" htmlFor="routine-title-input">Routine title</label>
                <input
                  type="text"
                  id="routine-title-input"
                  value={currentRoutineName}
                  onChange={(e) => setCurrentRoutineName(e.target.value)}
                  placeholder="e.g. Heavy Single Workout"
                  className="bg-black border border-white/10 px-3.5 py-2.5 rounded text-sm font-bold text-white focus:outline-none focus:border-[#FF6321]"
                />
              </div>

              {/* Select dropdown of exercises */}
              <div className="flex-1 flex flex-col gap-1.5">
                <label className="text-[10px] font-mono tracking-widest text-gray-500 uppercase" htmlFor="selector-exercise-add">Add exercise target</label>
                <div className="flex gap-2">
                  <select
                    id="selector-exercise-add"
                    value={selectedExerciseId}
                    onChange={(e) => setSelectedExerciseId(e.target.value)}
                    className="flex-1 bg-black border border-white/10 px-3 py-2 rounded text-xs font-semibold text-white focus:outline-none focus:border-[#FF6321] h-10 cursor-pointer"
                  >
                    {exercises.map((e) => (
                      <option key={e.id} value={e.id} className="bg-[#1c1c1e]">
                        {e.name} ({e.muscle.toUpperCase()})
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={handleAddItem}
                    className="h-10 w-10 bg-[#FF6321] hover:bg-[#e55a1e] text-black flex items-center justify-center rounded cursor-pointer transition shadow"
                    id="add-exercise-to-routine-button"
                  >
                    <Plus className="w-5 h-5 stroke-[3px]" />
                  </button>
                </div>
              </div>
            </div>

            {/* List of current added exercise objects */}
            {items.length === 0 ? (
              <div className="flex flex-col items-center justify-center text-center py-16 border border-dashed border-white/5 rounded bg-black/20">
                <FileText className="w-8 h-8 text-gray-600 mb-3" />
                <h5 className="text-gray-400 text-sm font-bold">Workspace Active Template is Empty</h5>
                <p className="text-[11px] text-gray-550 max-w-[280px] mt-1 font-light">
                  Load a preset above or choose from the list to structure your workout.
                </p>
              </div>
            ) : (
              <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
                {items.map((item) => (
                  <div
                    key={item.id}
                    className="bg-black border border-white/5 rounded-lg p-4 flex flex-col md:flex-row justify-between md:items-center gap-4 hover:border-white/10 transition"
                    id={`workout-item-${item.id}`}
                  >
                    <div className="space-y-1">
                      <span className="text-xs font-bold text-white tracking-tight">
                        {item.exerciseName}
                      </span>
                      <div className="flex flex-wrap items-center gap-1.5">
                        {item.sets.map((set, sIdx) => (
                          <div
                            key={sIdx}
                            className="bg-[#1c1c1e] text-[10px] text-gray-400 border border-white/5 px-2 py-0.5 rounded inline-flex items-center gap-1 font-mono"
                            id={`routine-badge-${item.id}-${sIdx}`}
                          >
                            <span>S{sIdx + 1}:</span>
                            <span className="text-[#FF6321] font-bold">{set.reps}</span> L @{' '}
                            <span className="text-white font-bold">{set.weight}</span> kg
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Quick Adjust controls */}
                    <div className="flex flex-wrap items-center gap-2">
                      <div className="bg-[#1c1c1e] p-1.5 rounded border border-white/5 flex items-center gap-3">
                        <div className="flex items-center gap-1">
                          <span className="text-[9px] text-gray-500 font-mono">REPS</span>
                          <input
                            type="number"
                            min="1"
                            value={item.sets[item.sets.length - 1]?.reps || 10}
                            onChange={(e) =>
                              handleUpdateSet(
                                item.id,
                                item.sets.length - 1,
                                'reps',
                                Math.max(1, parseInt(e.target.value) || 1)
                              )
                            }
                            className="w-10 bg-black border border-white/10 rounded px-1 text-center text-xs font-bold text-white focus:outline-none"
                            id={`rep-input-${item.id}`}
                          />
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-[9px] text-gray-500 font-mono">KG</span>
                          <input
                            type="number"
                            min="1"
                            value={item.sets[item.sets.length - 1]?.weight || 60}
                            onChange={(e) =>
                              handleUpdateSet(
                                item.id,
                                item.sets.length - 1,
                                'weight',
                                Math.max(1, parseInt(e.target.value) || 1)
                              )
                            }
                            className="w-12 bg-black border border-white/10 rounded px-1 text-center text-xs font-bold text-white focus:outline-none"
                            id={`weight-input-${item.id}`}
                          />
                        </div>
                      </div>

                      <button
                        onClick={() => handleAddSet(item.id)}
                        className="px-2.5 py-1.5 bg-[#1c1c1e] hover:bg-neutral-800 text-gray-200 border border-white/5 text-[10px] font-bold rounded cursor-pointer transition uppercase font-mono"
                        id={`add-set-button-${item.id}`}
                      >
                        + Set
                      </button>

                      <button
                        onClick={() => handleDeleteSet(item.id, item.sets.length - 1)}
                        className="p-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded cursor-pointer transition"
                        title="Delete Last Set"
                        id={`delete-set-button-${item.id}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Action Footer */}
          {items.length > 0 && (
            <div className="mt-8 flex flex-wrap gap-3 pt-4 border-t border-white/5">
              <button
                onClick={handleSaveRoutine}
                className="flex-1 min-w-[140px] py-3 bg-[#FF6321] hover:bg-[#e55a1e] text-black rounded text-xs font-bold tracking-wider cursor-pointer transition flex items-center justify-center gap-1.5"
                id="routine-save-button"
              >
                <Save className="w-4 h-4 text-black stroke-[2.5px]" />
                SAVE TO TEMPLATES
              </button>
              <button
                onClick={handleExportRoutine}
                className="flex-1 min-w-[140px] py-3 bg-black hover:bg-neutral-900 text-gray-300 rounded text-xs font-bold tracking-wider border border-white/10 cursor-pointer transition flex items-center justify-center gap-1.5"
                id="routine-export-button"
              >
                <Download className="w-4 h-4 text-[#FF6321]" />
                EXPORT TEXTSplit
              </button>
              <button
                onClick={() => {
                  setItems([]);
                  triggerNotification('Workspace reset.');
                }}
                className="px-4 py-3 bg-red-500/10 hover:bg-red-500/20 text-red-500 hover:text-red-400 rounded text-xs font-bold cursor-pointer transition uppercase"
                id="routine-clear-all"
              >
                Reset
              </button>
            </div>
          )}
        </div>

        {/* Saved routines side board (Right 4 cols) */}
        <div className="lg:col-span-4 bg-black/30 p-5 rounded-xl border border-white/5 flex flex-col justify-between">
          <div>
            <h4 className="text-[11px] font-mono font-bold text-[#FF6321] tracking-widest uppercase mb-4">
              🗄️ Cached splits
            </h4>

            {routines.length === 0 ? (
              <div className="py-12 text-center text-gray-600 text-[11px] italic font-light">
                No custom splits stored in browser cache yet.
              </div>
            ) : (
              <div className="space-y-2.5">
                {routines.map((r) => (
                  <div
                    key={r.id}
                    className="p-3 bg-black hover:bg-[#1a1a1c] border border-white/5 rounded flex justify-between items-center group transition"
                    id={`saved-routine-${r.id}`}
                  >
                    <div
                      className="cursor-pointer flex-1"
                      onClick={() => handleLoadSavedRoutine(r)}
                    >
                      <h4 className="text-xs font-bold text-gray-300 group-hover:text-[#FF6321] transition line-clamp-1">
                        {r.name}
                      </h4>
                      <p className="text-[9px] text-gray-500 font-mono mt-0.5">
                        {r.items.length} Exercises • Saved {r.createdAt}
                      </p>
                    </div>

                    <button
                      onClick={() => handleDeleteRoutine(r.id)}
                      className="p-1 px-1.5 text-gray-650 hover:text-red-400 cursor-pointer transition"
                      title="Remove Split"
                      id={`delete-routine-block-${r.id}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="mt-8 pt-4 border-t border-white/5 flex items-center gap-3 bg-black/60 p-3 rounded">
            <Play className="w-5 h-5 text-[#FF6321] shrink-0 animate-pulse" />
            <div>
              <h5 className="text-[10px] font-bold text-gray-300">Anatomical Coordination</h5>
              <p className="text-[9px] text-gray-500 leading-snug font-light">
                Base your compound load targets recursively from TDEE values in the physiology tabs above.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
