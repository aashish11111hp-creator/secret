import React, { useState } from 'react';
import { Calendar, Check, Send, Award, Shield, User, MapPin, X, AlertCircle } from 'lucide-react';

interface BookingDialogProps {
  isOpen: boolean;
  onClose: () => void;
  initialType?: 'trial' | 'membership';
}

export default function BookingDialog({ isOpen, onClose, initialType = 'trial' }: BookingDialogProps) {
  const [activeSegment, setActiveSegment] = useState<'trial' | 'plans'>(initialType);
  const [formError, setFormError] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    branch: 'Butwal',
    specialty: 'Bodybuilding / Hypertrophy',
    date: '2026-06-20',
  });
  const [bookedReceipt, setBookedReceipt] = useState<any | null>(null);

  if (!isOpen) return null;

  const handleInputChange = (key: string, val: string) => {
    setFormError('');
    setFormData((prev) => ({ ...prev, [key]: val }));
  };

  const handleSubmitTrial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.phone.trim()) {
      setFormError('Please input your name and Nepal telephone number.');
      return;
    }

    const receipt = {
      bookingId: 'EVO-' + Math.floor(100000 + Math.random() * 900000),
      ...formData,
      trainer: formData.specialty === 'Strength & Power' ? 'Coach Sandesh (Elite Powerlifter)' : 'Coach Pradip (Pro Bodybuilder)',
    };

    setBookedReceipt(receipt);
  };

  const membershipPlans = [
    {
      name: 'Starter Week pass',
      price: 'NPR 1,200',
      period: '7 days access',
      features: [
        'Gym floors in both Butwal & Kathmandu',
        '24/7 Access to dumbbells & machines',
        '1x Expert form check session',
        'Locker room & high speed Wi-Fi'
      ],
      popular: false,
    },
    {
      name: 'Titan Strength Club',
      price: 'NPR 4,500',
      period: 'Monthly pass',
      features: [
        'All Starter tier features included',
        'Unlimited heavy deadlift platforms',
        '3x Personal coaching sessions included',
        'Custom macro consultation setup',
        'Access to group training masterclass'
      ],
      popular: true,
    },
    {
      name: 'Black Label Elite VIP',
      price: 'NPR 38,000',
      period: 'Yearly VIP Pass',
      features: [
        'Unlimited access across both branches',
        'Full personal coach assigned',
        'Free supplement shaker & muscle tees',
        'Priority booking for powerlifting racks',
        'Complimentary physical massage therapy / month'
      ],
      popular: false,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md" id="booking-modal-overlay">
      
      {/* Container */}
      <div className="relative w-full max-w-3xl bg-[#1c1c1e] border border-white/10 rounded-2xl overflow-hidden shadow-2xl flex flex-col md:flex-row max-h-[90vh]">
        
        {/* Absolute exit */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white transition z-20"
          title="Exit menu"
          id="exit-booking-dialog"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Info Column (Left panel) */}
        <div className="w-full md:w-2/5 bg-black p-6 flex flex-col justify-between border-b md:border-b-0 md:border-r border-white/5">
          <div>
            <div className="flex items-center gap-1.5 text-gray-400 mb-2 font-mono text-[10px]">
              <MapPin className="w-3.5 h-3.5 text-[#FF6321]" />
              <span>NEPAL’S ULTIMATE SQUAD</span>
            </div>
            <h3 className="text-xl font-extrabold text-[#FF6321] tracking-tight uppercase">
              EVOLVE <span className="text-white">FITNESS</span>
            </h3>
            <p className="text-xs text-gray-400 mt-2 leading-relaxed font-light">
              Join the highest density powerlifting, hypertrophy, and functional training environment in Kathmandu and Butwal. No gimmicks, just premium iron.
            </p>
          </div>

          <div className="space-y-4 my-8 md:my-0">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-[#FF6321]/10 rounded">
                <Award className="w-4 h-4 text-[#FF6321]" />
              </div>
              <div>
                <h5 className="text-[11px] font-bold text-gray-300">Hammer Strength Rigged</h5>
                <p className="text-[9px] text-gray-550">Official Hammer Strength layout</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="p-2 bg-[#FF6321]/10 rounded">
                <Shield className="w-4 h-4 text-[#FF6321]" />
              </div>
              <div>
                <h5 className="text-[11px] font-bold text-gray-300">Certified Coaching Support</h5>
                <p className="text-[9px] text-gray-550">Form mechanics verified at standard levels</p>
              </div>
            </div>
          </div>

          <div className="text-[9px] text-gray-600 font-mono">
            ESTABLISHED 2021 • KATHMANDU / BUTWAL
          </div>
        </div>

        {/* Action Column (Right panel) */}
        <div className="w-full md:w-3/5 p-6 md:p-8 flex flex-col overflow-y-auto">
          {/* Tabs switch */}
          {!bookedReceipt && (
            <div className="flex border-b border-white/5 pb-3 mb-6 gap-6">
              <button
                onClick={() => { setActiveSegment('trial'); setFormError(''); }}
                className={`text-xs font-mono font-bold tracking-wider transition pb-2 ${
                  activeSegment === 'trial' ? 'text-[#FF6321] border-b-2 border-[#FF6321]' : 'text-gray-500 hover:text-gray-300'
                }`}
                id="booking-segment-trial"
              >
                1. BOOK FREE TRIAL
              </button>
              <button
                onClick={() => { setActiveSegment('plans'); setFormError(''); }}
                className={`text-xs font-mono font-bold tracking-wider transition pb-2 ${
                  activeSegment === 'plans' ? 'text-[#FF6321] border-b-2 border-[#FF6321]' : 'text-gray-500 hover:text-gray-300'
                }`}
                id="booking-segment-plans"
              >
                2. VIEW MEMBERSHIPS
              </button>
            </div>
          )}

          {formError && (
            <div className="mb-4 bg-red-500/10 border border-red-500/20 text-red-400 p-3 rounded text-xs flex items-center gap-2 font-light">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          {bookedReceipt ? (
            <div className="flex flex-col items-center justify-center text-center py-8 space-y-4" id="booking-success-receipt">
              <div className="h-12 w-12 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <Check className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <h4 className="text-lg font-bold text-white uppercase">Trial Verified!</h4>
                <p className="text-xs text-gray-500 mt-1">Present this token receipt at the reception desk to sign in.</p>
              </div>

              {/* Token Invoice box */}
              <div className="w-full bg-black border border-white/5 p-4 rounded-xl text-left font-mono space-y-1.5 text-xs">
                <div>
                  <span className="text-gray-550">PASS_TOKEN:</span>{' '}
                  <span className="font-bold text-[#FF6321]">{bookedReceipt.bookingId}</span>
                </div>
                <div>
                  <span className="text-gray-550">ATHLETE:</span>{' '}
                  <span className="text-white font-bold">{bookedReceipt.name}</span>
                </div>
                <div>
                  <span className="text-gray-550">TELEPHONE:</span>{' '}
                  <span className="text-white">{bookedReceipt.phone}</span>
                </div>
                <div>
                  <span className="text-gray-550">HQ BRANCH:</span>{' '}
                  <span className="text-white font-bold">{bookedReceipt.branch} Location</span>
                </div>
                <div>
                  <span className="text-gray-550">SPECIALTY COACH:</span>{' '}
                  <span className="text-[#FF6321]">{bookedReceipt.trainer}</span>
                </div>
                <div>
                  <span className="text-gray-550">DATE ASSIGNED:</span>{' '}
                  <span className="text-gray-400">{bookedReceipt.date}</span>
                </div>
              </div>

              <div className="flex gap-2 w-full pt-4">
                <button
                  onClick={() => setBookedReceipt(null)}
                  className="flex-1 py-2.5 rounded bg-black border border-white/10 text-gray-400 text-xs font-bold font-mono transition hover:bg-[#111111]"
                  id="reset-booking-trial"
                >
                  NEW BOOKING
                </button>
                <button
                  onClick={onClose}
                  className="flex-1 py-2.5 rounded bg-[#FF6321] hover:bg-[#e55a1e] text-black text-xs font-bold font-mono transition"
                  id="close-booking-success"
                >
                  DONE
                </button>
              </div>
            </div>
          ) : activeSegment === 'trial' ? (
            <form onSubmit={handleSubmitTrial} className="space-y-4" id="booking-trial-form">
              {/* Name */}
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-mono text-gray-400" htmlFor="booking-name-input">FULL NAME</label>
                <div className="relative">
                  <User className="absolute left-3 top-3.5 w-4 h-4 text-gray-600" />
                  <input
                    type="text"
                    id="booking-name-input"
                    required
                    value={formData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    placeholder="Aarav Sharma"
                    className="w-full bg-black border border-white/10 pl-10 pr-4 py-2.5 rounded text-sm font-semibold text-white focus:outline-none focus:border-[#FF6321]"
                  />
                </div>
              </div>

              {/* Grid: Phone / email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-mono text-gray-400" htmlFor="booking-phone-input">NEPAL TELEPHONE NUMBER</label>
                  <input
                    type="tel"
                    id="booking-phone-input"
                    required
                    value={formData.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    placeholder="98********"
                    className="w-full bg-black border border-white/10 px-4 py-2.5 rounded text-sm font-semibold text-white focus:outline-none focus:border-[#FF6321]"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-mono text-gray-400" htmlFor="booking-email-input">EMAIL (Optional)</label>
                  <input
                    type="email"
                    id="booking-email-input"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    placeholder="aarav@gmail.com"
                    className="w-full bg-black border border-white/10 px-4 py-2.5 rounded text-sm font-semibold text-white focus:outline-none focus:border-[#FF6321]"
                  />
                </div>
              </div>

              {/* Grid: Branch / Specialty */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-mono text-gray-400" htmlFor="booking-branch-select">TARGET PREFERRED BRANCH</label>
                  <select
                    id="booking-branch-select"
                    value={formData.branch}
                    onChange={(e) => handleInputChange('branch', e.target.value)}
                    className="w-full bg-black border border-white/10 px-4 py-2.5 rounded text-xs font-semibold text-white focus:outline-none focus:border-[#FF6321]"
                  >
                    <option value="Butwal" className="bg-[#1c1c1e]">Butwal Branch (Milanchowk HQ)</option>
                    <option value="Kathmandu" className="bg-[#1c1c1e]">Kathmandu Branch (Thamel Rig)</option>
                  </select>
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-mono text-gray-400" htmlFor="booking-focus-select">TRAINING TARGET FOCUS</label>
                  <select
                    id="booking-focus-select"
                    value={formData.specialty}
                    onChange={(e) => handleInputChange('specialty', e.target.value)}
                    className="w-full bg-black border border-white/10 px-4 py-2.5 rounded text-xs font-semibold text-white focus:outline-none focus:border-[#FF6321]"
                  >
                    <option value="Bodybuilding / Hypertrophy" className="bg-[#1c1c1e]">Bodybuilding / Hypertrophy</option>
                    <option value="Strength & Power" className="bg-[#1c1c1e]">Powerlifting / Strength Coach</option>
                    <option value="Functional / Conditioning" className="bg-[#1c1c1e]">Functional / Conditioning</option>
                  </select>
                </div>
              </div>

              {/* Target date */}
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-mono text-gray-400" htmlFor="booking-date-input">REQUESTED TRAINING DATE</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-3.5 w-4 h-4 text-gray-600" />
                  <input
                    type="date"
                    id="booking-date-input"
                    value={formData.date}
                    onChange={(e) => handleInputChange('date', e.target.value)}
                    className="w-full bg-black border border-white/10 pl-10 pr-4 py-2.5 rounded text-sm font-semibold text-white focus:outline-none focus:border-[#FF6321]"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full mt-6 py-3.5 bg-[#FF6321] hover:bg-[#e55a1e] text-black rounded text-xs font-bold tracking-widest transition flex items-center justify-center gap-2 shadow-xl shadow-[#FF6321]/10 font-sans"
                id="booking-submit-btn"
              >
                <Send className="w-4 h-4" />
                VERIFY FREE TRIAL ACCESS
              </button>
            </form>
          ) : (
            <div className="space-y-4" id="booking-plans-grid">
              <div className="space-y-4 max-h-[420px] overflow-y-auto pr-1">
                {membershipPlans.map((plan) => (
                  <div
                    key={plan.name}
                    className={`p-5 rounded-2xl border transition-all ${
                      plan.popular
                        ? 'bg-[#FF6321]/5 border-[#FF6321] relative'
                        : 'bg-black border-white/5 hover:border-white/10'
                    }`}
                    id={`membership-card-${plan.name.replace(/\s+/g, '-').toLowerCase()}`}
                  >
                    {plan.popular && (
                      <span className="absolute -top-3 right-4 bg-[#FF6321] text-black text-[9px] font-mono font-bold px-2 py-0.5 rounded uppercase">
                        MOST POPULAR PASS
                      </span>
                    )}

                    <div className="flex justify-between items-baseline mb-2">
                      <h4 className="text-sm font-bold text-white tracking-wide">{plan.name}</h4>
                      <div className="text-right">
                        <span className="text-base font-extrabold text-[#FF6321] font-mono">{plan.price}</span>
                        <span className="text-[10px] text-gray-500 font-mono italic"> / {plan.period}</span>
                      </div>
                    </div>

                    <ul className="space-y-1.5 mt-4">
                      {plan.features.map((feat) => (
                        <li key={feat} className="text-xs text-gray-400 flex items-center gap-2 font-light">
                          <Check className="w-3.5 h-3.5 text-[#FF6321] shrink-0" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>

              <button
                onClick={() => { setActiveSegment('trial'); setFormError(''); }}
                className="w-full mt-2 py-3 bg-black hover:bg-[#1a1a1c] text-gray-300 text-xs font-bold tracking-wider rounded transition border border-white/10 text-center uppercase"
                id="transfer-plans-to-trial"
              >
                Book Free Trial before purchasing plan
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
