import React, { useState } from 'react';
import { MuscleGroup, Gender, ViewDirection } from '../types';
import { Activity, RefreshCw } from 'lucide-react';

interface BodyMapProps {
  selectedMuscle: MuscleGroup | null;
  onSelectMuscle: (muscle: MuscleGroup) => void;
  gender: Gender;
  setGender: (g: Gender) => void;
  view: ViewDirection;
  setView: (v: ViewDirection) => void;
}

export default function BodyMap({
  selectedMuscle,
  onSelectMuscle,
  gender,
  setGender,
  view,
  setView,
}: BodyMapProps) {
  const [hoveredMuscle, setHoveredMuscle] = useState<MuscleGroup | null>(null);

  // Define interactive layout muscles based on ViewDirection
  const frontMuscles = [
    { id: 'traps', label: 'Traps', pos: 'top-10 left-12 md:left-16', path: 'M 175,100 L 190,120 L 178,135 L 160,120 Z' },
    { id: 'shoulders', label: 'Shoulders', pos: 'h-10 w-24' },
    { id: 'chest', label: 'Chest', pos: 'h-16 w-32' },
    { id: 'biceps', label: 'Biceps', pos: 'h-12 w-10' },
    { id: 'abs', label: 'Abs', pos: 'h-24 w-16' },
    { id: 'forearms', label: 'Forearms', pos: 'h-16 w-8' },
    { id: 'quads', label: 'Quads', pos: 'h-36 w-24' },
  ] as const;

  const backMuscles = [
    { id: 'traps', label: 'Traps' },
    { id: 'shoulders', label: 'Rear Delts' },
    { id: 'triceps', label: 'Triceps' },
    { id: 'lats', label: 'Lats' },
    { id: 'lower-back', label: 'Lower Back' },
    { id: 'glutes', label: 'Glutes' },
    { id: 'hamstrings', label: 'Hamstrings' },
    { id: 'calves', label: 'Calves' },
  ] as const;

  const activeMuscleList = view === 'front' ? frontMuscles : backMuscles;

  // Render SVG segments representing high-tech muscles
  const renderSvgMuscles = () => {
    if (view === 'front') {
      return (
        <svg viewBox="0 0 400 650" className="w-full max-h-[480px] select-none text-zinc-600 transition-all duration-300">
          {/* Subtle Glow Background Grid */}
          <defs>
            <radialGradient id="neonGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#ff5500" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#111" stopOpacity="0" />
            </radialGradient>
          </defs>
          <circle cx="200" cy="220" r="160" fill="url(#neonGlow)" />

          {/* HEAD Outline */}
          <ellipse cx="200" cy="65" rx="22" ry="28" className="fill-zinc-800 stroke-zinc-700 stroke-2" />
          <path d="M 190,92 L 190,110 L 210,110 L 210,92 Z" className="fill-zinc-800 stroke-zinc-700 stroke-2" />

          {/* TRAPS (Front) */}
          <path
            id="trap-l"
            d="M 178,92 Q 175,108 152,120 Q 170,123 182,110 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'traps'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'traps'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('traps')}
            onMouseEnter={() => setHoveredMuscle('traps')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />
          <path
            id="trap-r"
            d="M 222,92 Q 225,108 248,120 Q 230,123 218,110 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'traps'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'traps'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('traps')}
            onMouseEnter={() => setHoveredMuscle('traps')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />

          {/* SHOULDERS / DELTOIDS */}
          <path
            id="shoulder-l"
            d="M 152,120 Q 130,135 140,175 Q 155,160 162,130 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'shoulders'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'shoulders'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('shoulders')}
            onMouseEnter={() => setHoveredMuscle('shoulders')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />
          <path
            id="shoulder-r"
            d="M 248,120 Q 270,135 260,175 Q 245,160 238,130 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'shoulders'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'shoulders'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('shoulders')}
            onMouseEnter={() => setHoveredMuscle('shoulders')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />

          {/* CHEST */}
          <path
            id="chest-l"
            d="M 163,130 Q 185,130 198,135 L 198,185 Q 180,185 158,165 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'chest'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'chest'
                ? 'fill-[#ff5500]/45 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('chest')}
            onMouseEnter={() => setHoveredMuscle('chest')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />
          <path
            id="chest-r"
            d="M 237,130 Q 215,130 202,135 L 202,185 Q 220,185 242,165 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'chest'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'chest'
                ? 'fill-[#ff5500]/45 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('chest')}
            onMouseEnter={() => setHoveredMuscle('chest')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />

          {/* BICEPS */}
          <path
            id="bicep-l"
            d="M 140,175 Q 128,215 138,235 L 146,215 Q 155,185 148,175 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'biceps'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'biceps'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('biceps')}
            onMouseEnter={() => setHoveredMuscle('biceps')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />
          <path
            id="bicep-r"
            d="M 260,175 Q 272,215 262,235 L 254,215 Q 245,185 252,175 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'biceps'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'biceps'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('biceps')}
            onMouseEnter={() => setHoveredMuscle('biceps')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />

          {/* ABS */}
          <path
            id="abs-body"
            d="M 175,190 L 225,190 L 220,285 L 180,285 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'abs'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'abs'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('abs')}
            onMouseEnter={() => setHoveredMuscle('abs')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />

          {/* FOREARMS */}
          <path
            id="forearm-l"
            d="M 134,235 Q 120,290 135,315 L 140,295 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'forearms'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'forearms'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('forearms')}
            onMouseEnter={() => setHoveredMuscle('forearms')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />
          <path
            id="forearm-r"
            d="M 266,235 Q 280,290 265,315 L 260,295 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'forearms'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'forearms'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('forearms')}
            onMouseEnter={() => setHoveredMuscle('forearms')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />

          {/* QUADS */}
          <path
            id="quad-l"
            d="M 172,298 Q 146,380 178,460 L 194,460 Q 192,380 183,298 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'quads'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'quads'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('quads')}
            onMouseEnter={() => setHoveredMuscle('quads')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />
          <path
            id="quad-r"
            d="M 228,298 Q 254,380 222,460 L 206,460 Q 208,380 217,298 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'quads'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'quads'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('quads')}
            onMouseEnter={() => setHoveredMuscle('quads')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />

          {/* CALVES (Front indicators) */}
          <path
            id="calf-front-l"
            d="M 170,480 Q 155,540 174,600 L 180,600 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'calves'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'calves'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('calves')}
            onMouseEnter={() => setHoveredMuscle('calves')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />
          <path
            id="calf-front-r"
            d="M 230,480 Q 245,540 226,600 L 220,600 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'calves'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'calves'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('calves')}
            onMouseEnter={() => setHoveredMuscle('calves')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />

          {/* Hands and feet indicators (non-interactive) */}
          <path d="M 130,314 L 126,330 L 134,330 Z" className="fill-zinc-800 stroke-zinc-700" />
          <path d="M 270,314 L 274,330 L 266,330 Z" className="fill-zinc-800 stroke-zinc-700" />
          <path d="M 174,600 L 168,615 L 182,615 Z" className="fill-zinc-800 stroke-zinc-700" />
          <path d="M 226,600 L 232,615 L 218,615 Z" className="fill-zinc-800 stroke-zinc-700" />
        </svg>
      );
    } else {
      return (
        <svg viewBox="0 0 400 650" className="w-full max-h-[480px] select-none text-zinc-600 transition-all duration-300">
          {/* Subtle Glow Background Grid */}
          <defs>
            <radialGradient id="neonGlowBack" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#ff5500" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#111" stopOpacity="0" />
            </radialGradient>
          </defs>
          <circle cx="200" cy="220" r="160" fill="url(#neonGlowBack)" />

          {/* HEAD Outline */}
          <ellipse cx="200" cy="65" rx="22" ry="28" className="fill-zinc-800 stroke-zinc-700 stroke-2" />
          <path d="M 190,92 L 190,110 L 210,110 L 210,92 Z" className="fill-zinc-800 stroke-zinc-700 stroke-2" />

          {/* TRAPEZIUS (Full back traps) */}
          <path
            id="trap-back"
            d="M 183,93 L 217,93 L 235,123 L 200,158 L 165,123 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'traps'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'traps'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('traps')}
            onMouseEnter={() => setHoveredMuscle('traps')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />

          {/* SHOULDERS (Rear delts) */}
          <path
            id="rear-delt-l"
            d="M 165,123 L 150,123 Q 132,138 141,170 Q 155,160 162,143 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'shoulders'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'shoulders'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('shoulders')}
            onMouseEnter={() => setHoveredMuscle('shoulders')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />
          <path
            id="rear-delt-r"
            d="M 235,123 L 250,123 Q 268,138 259,170 Q 245,160 238,143 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'shoulders'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'shoulders'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('shoulders')}
            onMouseEnter={() => setHoveredMuscle('shoulders')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />

          {/* TRICEPS */}
          <path
            id="triceps-l"
            d="M 141,170 Q 128,214 139,235 L 148,206 Q 148,180 145,170 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'triceps'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'triceps'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('triceps')}
            onMouseEnter={() => setHoveredMuscle('triceps')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />
          <path
            id="triceps-r"
            d="M 259,170 Q 272,214 261,235 L 252,206 Q 252,180 255,170 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'triceps'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'triceps'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('triceps')}
            onMouseEnter={() => setHoveredMuscle('triceps')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />

          {/* LATS */}
          <path
            id="lat-l"
            d="M 165,130 Q 183,165 190,205 L 175,235 Q 165,215 158,165 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'lats'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'lats'
                ? 'fill-[#ff5500]/43 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('lats')}
            onMouseEnter={() => setHoveredMuscle('lats')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />
          <path
            id="lat-r"
            d="M 235,130 Q 217,165 210,205 L 225,235 Q 235,215 242,165 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'lats'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'lats'
                ? 'fill-[#ff5500]/43 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('lats')}
            onMouseEnter={() => setHoveredMuscle('lats')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />

          {/* LOWER BACK */}
          <path
            id="lower-back-body"
            d="M 183,235 L 217,235 L 213,285 L 187,285 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'lower-back'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'lower-back'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('lower-back')}
            onMouseEnter={() => setHoveredMuscle('lower-back')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />

          {/* GLUTES */}
          <path
            id="glute-l"
            d="M 166,288 H 198 V 338 H 176 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'glutes'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'glutes'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('glutes')}
            onMouseEnter={() => setHoveredMuscle('glutes')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />
          <path
            id="glute-r"
            d="M 202,288 H 234 V 338 H 224 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'glutes'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'glutes'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('glutes')}
            onMouseEnter={() => setHoveredMuscle('glutes')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />

          {/* HAMSTRINGS */}
          <path
            id="hamstring-l"
            d="M 168,345 Q 155,410 180,480 L 193,480 Q 185,410 183,345 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'hamstrings'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'hamstrings'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('hamstrings')}
            onMouseEnter={() => setHoveredMuscle('hamstrings')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />
          <path
            id="hamstring-r"
            d="M 232,345 Q 245,410 220,480 L 207,480 Q 215,410 217,345 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'hamstrings'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'hamstrings'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('hamstrings')}
            onMouseEnter={() => setHoveredMuscle('hamstrings')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />

          {/* CALVES (Back) */}
          <path
            id="calf-l"
            d="M 170,490 Q 155,545 174,600 L 180,600 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'calves'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'calves'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('calves')}
            onMouseEnter={() => setHoveredMuscle('calves')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />
          <path
            id="calf-r"
            d="M 230,490 Q 245,545 226,600 L 220,600 Z"
            className={`cursor-pointer transition-colors duration-200 ${
              selectedMuscle === 'calves'
                ? 'fill-[#ff5500] stroke-[#ff5500] filter drop-shadow-[0_0_8px_#ff5500]'
                : hoveredMuscle === 'calves'
                ? 'fill-[#ff5500]/40 stroke-[#ff5500]'
                : 'fill-zinc-800/80 stroke-zinc-700'
            }`}
            onClick={() => onSelectMuscle('calves')}
            onMouseEnter={() => setHoveredMuscle('calves')}
            onMouseLeave={() => setHoveredMuscle(null)}
          />
        </svg>
      );
    }
  };

  return (
    <div className="flex flex-col lg:flex-row items-center gap-8 bg-[#1c1c1e] p-6 rounded-2xl border border-white/5 shadow-xl backdrop-blur-md w-full max-w-5xl mx-auto" id="interactive-body-map-container">
      {/* Visual Map Side */}
      <div className="relative flex flex-col items-center w-full lg:w-3/5">
        {/* Toggle Switches */}
        <div className="flex justify-between items-center w-full mb-6 gap-3 z-10">
          {/* Gender Select */}
          <div className="flex bg-black p-1 rounded-lg border border-white/10">
            <button
              onClick={() => setGender('male')}
              className={`px-4 py-1.5 rounded text-xs font-semibold uppercase transition-all duration-200 ${
                gender === 'male'
                  ? 'bg-[#FF6321] text-black shadow-md font-black'
                  : 'text-gray-400 hover:text-white'
              }`}
              id="gender-toggle-male"
            >
              Male
            </button>
            <button
              onClick={() => setGender('female')}
              className={`px-4 py-1.5 rounded text-xs font-semibold uppercase transition-all duration-200 ${
                gender === 'female'
                  ? 'bg-[#FF6321] text-black shadow-md font-black'
                  : 'text-gray-400 hover:text-white'
              }`}
              id="gender-toggle-female"
            >
              Female
            </button>
          </div>

          {/* View direction switch */}
          <button
            onClick={() => setView(view === 'front' ? 'back' : 'front')}
            className="flex items-center gap-2 bg-black hover:bg-[#1c1c1e]/50 text-gray-300 hover:text-white px-4 py-2 rounded text-xs font-medium border border-white/10 transition-all duration-200 font-mono"
            id="view-direction-toggle"
          >
            <RefreshCw className="w-3 h-3 text-[#FF6321]" />
            <span>{view.toUpperCase()} VIEW</span>
          </button>

          <div className="text-gray-500 text-xs flex items-center gap-1 font-mono">
            <Activity className="w-3.5 h-3.5 text-[#FF6321] animate-pulse" />
            <span>Interactive Chart</span>
          </div>
        </div>

        {/* SVG Container */}
        <div className="relative w-full max-w-[340px] flex justify-center bg-black py-4 rounded-xl border border-white/5">
          {renderSvgMuscles()}
        </div>

        {/* Quick hint */}
        <div className="text-gray-400 text-xs mt-3 text-center font-light">
          💡 Click a target muscle group on the diagram to load tutorials immediately
        </div>
      </div>

      {/* Side list/dock for convenience */}
      <div className="w-full lg:w-2/5 flex flex-col self-stretch justify-between">
        <div>
          <div className="border-b border-white/5 pb-3 mb-4">
            <h4 className="text-sm font-semibold tracking-wider text-[#FF6321] uppercase font-mono">
              Anatomical selector
            </h4>
            <p className="text-xs text-gray-500 mt-1">
              Select any muscle group to find verified Evolve techniques.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {activeMuscleList.map((m) => {
              const isActive = selectedMuscle === m.id;
              const isHovered = hoveredMuscle === m.id;
              return (
                <button
                  key={m.id}
                  onClick={() => onSelectMuscle(m.id as MuscleGroup)}
                  onMouseEnter={() => setHoveredMuscle(m.id as MuscleGroup)}
                  onMouseLeave={() => setHoveredMuscle(null)}
                  className={`flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium border transition-all duration-200 text-left ${
                    isActive
                      ? 'bg-[#FF6321]/10 border-[#FF6321] text-white shadow-md'
                      : isHovered
                      ? 'bg-zinc-800 border-zinc-700 text-zinc-100'
                      : 'bg-black border-white/5 text-gray-400 hover:border-gray-700 hover:text-gray-300'
                  }`}
                  id={`muscle-choice-${m.id}`}
                >
                  <span>{m.label}</span>
                  {isActive && <span className="h-1.5 w-1.5 rounded-full bg-[#FF6321] animate-ping" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected target display block */}
        <div className="mt-6 lg:mt-0 p-4 rounded-xl bg-black border border-white/5 flex flex-col justify-between">
          <div className="flex justify-between items-center mb-1">
            <span className="text-[10px] font-mono text-gray-500">SELECTED TARGET</span>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
              READY
            </span>
          </div>
          <span className="text-xl font-bold tracking-tight text-white capitalize">
            {selectedMuscle ? selectedMuscle.replace('-', ' ') : 'Select a muscle'}
          </span>
          <p className="text-xs text-gray-400 mt-1 font-light">
            {selectedMuscle
              ? `Currently displaying expert routines targeting the ${selectedMuscle.replace(
                  '-',
                  ' '
                )} system.`
              : 'Interact with the 3D anatomical layout to filter exercise modules.'}
          </p>
        </div>
      </div>
    </div>
  );
}
